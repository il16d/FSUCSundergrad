﻿using System;

public class ModelsBill
{
	public int Id { get; set; }
	public int Amount
	{ get; set; }
	public int CurrentBalance
	{ get; set; }
	public DateTime DueDate
	{ get; set; }
	public bool IsRecurring
	{ get; set; }
	public int LateFee
	{ get; set; }
	public string Payee
	{ get; set; }
	public int StartingBalance
	{ get; set; }
}
public class Payment
{
	public int Id { get; set; }
	public int Amount
	{ get; set; }
	public DateTime CheckDate
	{ get; set; }
	public string CheckNumber
	{ get; set; }
	public bool IsAutoPayment
	{ get; set; }
	public string Memo
	{ get; set; }
	public string Payee
	{ get; set; }
}
public class Goal
{
	public int Id { get; set; }
	public int CurrentBalance
	{ get; set; }
	public DateTime Deadline
	{ get; set; }
	public string Title
	{ get; set; }
	public int TotalGoal
	{ get; set; }
	public string description
	{ get; set; }
}
 
