﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
 
public class ModelsBillController : ApiController
{
	ModelsBill_EC modalData = new ModelsBill_EC();
	public async Task<IHttpActionResult> Get()
	{
		return Ok(modalData.Get());
	}
	public async Task<IHttpActionResult> GetById(int id)
	{
		var modal = modalData.GetById(id);
		if (modal == null)
			return NotFound();
		return Ok(modal);
	}
	[HttpPost]
	public async Task<IHttpActionResult> Search(string query)
	{
		return Ok(modalData.Search(query));
	}
	[HttpPost]
	public async Task<IHttpActionResult> AddOrUpdate(ModelsBill m)
	{
		return Ok(modalData.AddOrUpdate(m));
	}
	public async Task<IHttpActionResult> DeleteById(int id)
	{
		var modal = modalData.DeleteById(id);
		if (modal == null)
			return NotFound();
		return Ok(modal);
	}
	[HttpPost]
	public async Task<IHttpActionResult> Delete(ModelsBill m)
	{
		var modal = modalData.DeleteById(m.Id);
		if (modal == null)
			return NotFound();
		return Ok(modal);
	}
}
public class PaymentController : ApiController
{
	Payment_EC modalData = new Payment_EC();
	public async Task<IHttpActionResult> Get()
	{
		return Ok(modalData.Get());
	}
	public async Task<IHttpActionResult> GetById(int id)
	{
		var modal = modalData.GetById(id);
		if (modal == null)
			return NotFound();
		return Ok(modal);
	}
	[HttpPost]
	public async Task<IHttpActionResult> Search(string query)
	{
		return Ok(modalData.Search(query));
	}
	[HttpPost]
	public async Task<IHttpActionResult> AddOrUpdate(Payment m)
	{
		return Ok(modalData.AddOrUpdate(m));
	}
	public async Task<IHttpActionResult> DeleteById(int id)
	{
		var modal = modalData.DeleteById(id);
		if (modal == null)
			return NotFound();
		return Ok(modal);
	}
	[HttpPost]
	public async Task<IHttpActionResult> Delete(Payment m)
	{
		var modal = modalData.DeleteById(m.Id);
		if (modal == null)
			return NotFound();
		return Ok(modal);
	}
}
public class GoalController : ApiController
{
	Goal_EC modalData = new Goal_EC();
	public async Task<IHttpActionResult> Get()
	{
		return Ok(modalData.Get());
	}
	public async Task<IHttpActionResult> GetById(int id)
	{
		var modal = modalData.GetById(id);
		if (modal == null)
			return NotFound();
		return Ok(modal);
	}
	[HttpPost]
	public async Task<IHttpActionResult> Search(string query)
	{
		return Ok(modalData.Search(query));
	}
	[HttpPost]
	public async Task<IHttpActionResult> AddOrUpdate(Goal m)
	{
		return Ok(modalData.AddOrUpdate(m));
	}
	public async Task<IHttpActionResult> DeleteById(int id)
	{
		var modal = modalData.DeleteById(id);
		if (modal == null)
			return NotFound();
		return Ok(modal);
	}
	[HttpPost]
	public async Task<IHttpActionResult> Delete(Goal m)
	{
		var modal = modalData.DeleteById(m.Id);
		if (modal == null)
			return NotFound();
		return Ok(modal);
	}
}
 
