﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using System.IO;
using System.Linq;

public class ModelsBill_EC
{
	public static List<ModelsBill> ModelsBills { get; set; }
	static string  DATAFILENAME = "ModelsBills_data.csv";
	//Read Data
	static void ReadData()
	{
		ModelsBills = new List<ModelsBill>();
		if (File.Exists(DATAFILENAME))
		{
			foreach(string row in File.ReadAllLines(DATAFILENAME))
			{
				var m = new ModelsBill();
				var cols =  row.Split(',');
				m.Id = int.Parse(cols[0]);
				if (!string.IsNullOrEmpty(cols[1]))
					m.Amount = int.Parse(cols[1]);
				if (!string.IsNullOrEmpty(cols[2]))
					m.CurrentBalance = int.Parse(cols[2]);
				if (!string.IsNullOrEmpty(cols[3]))
					m.DueDate = DateTime.Parse(cols[3]);
				if (!string.IsNullOrEmpty(cols[4]))
					m.IsRecurring = bool.Parse(cols[4]);
				if (!string.IsNullOrEmpty(cols[5]))
					m.LateFee = int.Parse(cols[5]);
				m.Payee = cols[6];
				if (!string.IsNullOrEmpty(cols[7]))
					m.StartingBalance = int.Parse(cols[7]);
				ModelsBills.Add(m);
			}
		}
	}
	//Write Data
	static void WriteData()
	{
		if (ModelsBills != null)
		{
			List<String> records = new List<string>();
			foreach(var m in ModelsBills)
			{
				List<String> line = new List<string>();
				line.Add(Convert.ToString(m.Id));
				line.Add(Convert.ToString(m.Amount));
				line.Add(Convert.ToString(m.CurrentBalance));
				line.Add(Convert.ToString(m.DueDate));
				line.Add(Convert.ToString(m.IsRecurring));
				line.Add(Convert.ToString(m.LateFee));
				line.Add(Convert.ToString(m.Payee));
				line.Add(Convert.ToString(m.StartingBalance));

				records.Add(string.Join(",",line.ToArray()));
			}
			File.WriteAllLines(DATAFILENAME, records);
		}
	}
	public List<ModelsBill> Get()
	{
		ReadData();
		return ModelsBills;
	}
	public  ModelsBill GetById(int id)
	{
		ReadData();
		return ModelsBills.Where(x => x.Id == id).FirstOrDefault();
	}
	public List<ModelsBill> Search(string query)
	{
		var data = ModelsBills.ToDataTable();
		data.DefaultView.RowFilter = query;
		return data.DefaultView.ToTable().ToListof<ModelsBill>(); 
	}
	public ModelsBill AddOrUpdate(ModelsBill m)
	{
		ReadData();
		var existingData = GetById(m.Id);
		if (existingData == null)
		{
			m.Id = (ModelsBills.Max(x =>  (int?)x.Id) ?? 0) + 1;
			ModelsBills.Add(m);
		}
		else
		{
			existingData.Amount = m.Amount;
			existingData.CurrentBalance = m.CurrentBalance;
			existingData.DueDate = m.DueDate;
			existingData.IsRecurring = m.IsRecurring;
			existingData.LateFee = m.LateFee;
			existingData.Payee = m.Payee;
			existingData.StartingBalance = m.StartingBalance;
		}
		WriteData(); //Saves data to file
		return m;
	}
	public ModelsBill DeleteById(int id)
	{
		ReadData();
		var existingData = GetById(id);
		if (existingData != null)
		{
			ModelsBills.Remove(existingData);
			WriteData(); //Saves data to file
			return existingData;
		}
		return null;
	}
	public ModelsBill Delete(ModelsBill m)
	{
		ReadData();
		var existingData = GetById(m.Id);
		if (existingData != null)
		{
			ModelsBills.Remove(existingData);
			WriteData(); //Saves data to file
			return existingData;
		}
		return null;
	}
}
public class Payment_EC
{
	public static List<Payment> Payments { get; set; }
	static string  DATAFILENAME = "Payments_data.csv";
	//Read Data
	static void ReadData()
	{
		Payments = new List<Payment>();
		if (File.Exists(DATAFILENAME))
		{
			foreach(string row in File.ReadAllLines(DATAFILENAME))
			{
				var m = new Payment();
				var cols =  row.Split(',');
				m.Id = int.Parse(cols[0]);
				if (!string.IsNullOrEmpty(cols[1]))
					m.Amount = int.Parse(cols[1]);
				if (!string.IsNullOrEmpty(cols[2]))
					m.CheckDate = DateTime.Parse(cols[2]);
				m.CheckNumber = cols[3];
				if (!string.IsNullOrEmpty(cols[4]))
					m.IsAutoPayment = bool.Parse(cols[4]);
				m.Memo = cols[5];
				m.Payee = cols[6];
				Payments.Add(m);
			}
		}
	}
	//Write Data
	static void WriteData()
	{
		if (Payments != null)
		{
			List<String> records = new List<string>();
			foreach(var m in Payments)
			{
				List<String> line = new List<string>();
				line.Add(Convert.ToString(m.Id));
				line.Add(Convert.ToString(m.Amount));
				line.Add(Convert.ToString(m.CheckDate));
				line.Add(Convert.ToString(m.CheckNumber));
				line.Add(Convert.ToString(m.IsAutoPayment));
				line.Add(Convert.ToString(m.Memo));
				line.Add(Convert.ToString(m.Payee));

				records.Add(string.Join(",",line.ToArray()));
			}
			File.WriteAllLines(DATAFILENAME, records);
		}
	}
	public List<Payment> Get()
	{
		ReadData();
		return Payments;
	}
	public  Payment GetById(int id)
	{
		ReadData();
		return Payments.Where(x => x.Id == id).FirstOrDefault();
	}
	public List<Payment> Search(string query)
	{
		var data = Payments.ToDataTable();
		data.DefaultView.RowFilter = query;
		return data.DefaultView.ToTable().ToListof<Payment>(); 
	}
	public Payment AddOrUpdate(Payment m)
	{
		ReadData();
		var existingData = GetById(m.Id);
		if (existingData == null)
		{
			m.Id = (Payments.Max(x =>  (int?)x.Id) ?? 0) + 1;
			Payments.Add(m);
		}
		else
		{
			existingData.Amount = m.Amount;
			existingData.CheckDate = m.CheckDate;
			existingData.CheckNumber = m.CheckNumber;
			existingData.IsAutoPayment = m.IsAutoPayment;
			existingData.Memo = m.Memo;
			existingData.Payee = m.Payee;
		}
		WriteData(); //Saves data to file
		return m;
	}
	public Payment DeleteById(int id)
	{
		ReadData();
		var existingData = GetById(id);
		if (existingData != null)
		{
			Payments.Remove(existingData);
			WriteData(); //Saves data to file
			return existingData;
		}
		return null;
	}
	public Payment Delete(Payment m)
	{
		ReadData();
		var existingData = GetById(m.Id);
		if (existingData != null)
		{
			Payments.Remove(existingData);
			WriteData(); //Saves data to file
			return existingData;
		}
		return null;
	}
}
public class Goal_EC
{
	public static List<Goal> Goals { get; set; }
	static string  DATAFILENAME = "Goals_data.csv";
	//Read Data
	static void ReadData()
	{
		Goals = new List<Goal>();
		if (File.Exists(DATAFILENAME))
		{
			foreach(string row in File.ReadAllLines(DATAFILENAME))
			{
				var m = new Goal();
				var cols =  row.Split(',');
				m.Id = int.Parse(cols[0]);
				if (!string.IsNullOrEmpty(cols[1]))
					m.CurrentBalance = int.Parse(cols[1]);
				if (!string.IsNullOrEmpty(cols[2]))
					m.Deadline = DateTime.Parse(cols[2]);
				m.Title = cols[3];
				if (!string.IsNullOrEmpty(cols[4]))
					m.TotalGoal = int.Parse(cols[4]);
				m.description = cols[5];
				Goals.Add(m);
			}
		}
	}
	//Write Data
	static void WriteData()
	{
		if (Goals != null)
		{
			List<String> records = new List<string>();
			foreach(var m in Goals)
			{
				List<String> line = new List<string>();
				line.Add(Convert.ToString(m.Id));
				line.Add(Convert.ToString(m.CurrentBalance));
				line.Add(Convert.ToString(m.Deadline));
				line.Add(Convert.ToString(m.Title));
				line.Add(Convert.ToString(m.TotalGoal));
				line.Add(Convert.ToString(m.description));

				records.Add(string.Join(",",line.ToArray()));
			}
			File.WriteAllLines(DATAFILENAME, records);
		}
	}
	public List<Goal> Get()
	{
		ReadData();
		return Goals;
	}
	public  Goal GetById(int id)
	{
		ReadData();
		return Goals.Where(x => x.Id == id).FirstOrDefault();
	}
	public List<Goal> Search(string query)
	{
		var data = Goals.ToDataTable();
		data.DefaultView.RowFilter = query;
		return data.DefaultView.ToTable().ToListof<Goal>(); 
	}
	public Goal AddOrUpdate(Goal m)
	{
		ReadData();
		var existingData = GetById(m.Id);
		if (existingData == null)
		{
			m.Id = (Goals.Max(x =>  (int?)x.Id) ?? 0) + 1;
			Goals.Add(m);
		}
		else
		{
			existingData.CurrentBalance = m.CurrentBalance;
			existingData.Deadline = m.Deadline;
			existingData.Title = m.Title;
			existingData.TotalGoal = m.TotalGoal;
			existingData.description = m.description;
		}
		WriteData(); //Saves data to file
		return m;
	}
	public Goal DeleteById(int id)
	{
		ReadData();
		var existingData = GetById(id);
		if (existingData != null)
		{
			Goals.Remove(existingData);
			WriteData(); //Saves data to file
			return existingData;
		}
		return null;
	}
	public Goal Delete(Goal m)
	{
		ReadData();
		var existingData = GetById(m.Id);
		if (existingData != null)
		{
			Goals.Remove(existingData);
			WriteData(); //Saves data to file
			return existingData;
		}
		return null;
	}
}
//Helper Method for Datatable <-> List
static class Helper
	{
		public static List<T> ToListof<T>(this DataTable dt)
		{
			const BindingFlags flags = BindingFlags.Public | BindingFlags.Instance;
			var columnNames = dt.Columns.Cast<DataColumn>()
				.Select(c => c.ColumnName)
				.ToList();
			var objectProperties = typeof(T).GetProperties(flags);
			var targetList = dt.AsEnumerable().Select(dataRow =>
			{
				var instanceOfT = Activator.CreateInstance<T>();

				foreach (var properties in objectProperties.Where(properties => columnNames.Contains(properties.Name) && dataRow[properties.Name] != DBNull.Value))
				{
					properties.SetValue(instanceOfT, dataRow[properties.Name], null);
				}
				return instanceOfT;
			}).ToList();

			return targetList;
		}

		public static DataTable ToDataTable<T>(this List<T> items)
		{
			DataTable dataTable = new DataTable(typeof(T).Name);

			//Get all the properties
			PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
			foreach (PropertyInfo prop in Props)
			{
				//Defining type of data column gives proper data table 
				var type = (prop.PropertyType.IsGenericType && prop.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>) ? Nullable.GetUnderlyingType(prop.PropertyType) : prop.PropertyType);
				//Setting column names as Property names
				dataTable.Columns.Add(prop.Name, type);
			}
			foreach (T item in items)
			{
			   var values = new object[Props.Length];
			   for (int i = 0; i < Props.Length; i++)
			   {
					//inserting property values to datatable rows
					values[i] = Props[i].GetValue(item, null);
			   }
			   dataTable.Rows.Add(values);
		  }
		  //put a breakpoint here and check datatable
		  return dataTable;
		}
	}
 


/*WriteLine("{");
PushIndent("\t");
PopIndent();
WriteLine("}");
*/