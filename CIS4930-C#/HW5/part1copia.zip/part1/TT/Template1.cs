﻿ 
// This is the output code from your template
// you only get syntax-highlighting here - not intellisense
namespace MyNameSpace{
  class MyFirstGeneratedClass{
     public static void main (string[] args ){
       System.Console.WriteLine("Hello, the time is now: 11/29/2019 4:02:45 PM");
	   	 System.Console.Write(GetDataForTable("Rain"));
		 System.Console.Write(GetDataForTable("Temperatur"));
	     
     }
  static string GetDataForTable(string table){
     // TODO - will be implemented later...
     return "";
    }
  }
}
 
