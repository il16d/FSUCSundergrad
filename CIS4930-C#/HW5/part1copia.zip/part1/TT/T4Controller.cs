﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
 
public class ModelsBillController : ApiController
{
	public async Task<IHttpActionResult> Get()
	{
		return Ok(new List<ModelsBill>());
	}
	public async Task<IHttpActionResult> GetById(int id)
	{
		return Ok(default(ModelsBill));
	}
	[HttpPost]
	public async Task<IHttpActionResult> Search(string query)
	{
		return Ok(new List<ModelsBill>());
	}
	[HttpPost]
	public async Task<IHttpActionResult> AddOrUpdate(ModelsBill m)
	{
		return Ok(m);
	}
	public async Task<IHttpActionResult> DeleteById(int id)
	{
		return Ok(default(ModelsBill));
	}
	[HttpPost]
	public async Task<IHttpActionResult> Delete(ModelsBill m)
	{
		return Ok(m);
	}
}
public class PaymentController : ApiController
{
	public async Task<IHttpActionResult> Get()
	{
		return Ok(new List<Payment>());
	}
	public async Task<IHttpActionResult> GetById(int id)
	{
		return Ok(default(Payment));
	}
	[HttpPost]
	public async Task<IHttpActionResult> Search(string query)
	{
		return Ok(new List<Payment>());
	}
	[HttpPost]
	public async Task<IHttpActionResult> AddOrUpdate(Payment m)
	{
		return Ok(m);
	}
	public async Task<IHttpActionResult> DeleteById(int id)
	{
		return Ok(default(Payment));
	}
	[HttpPost]
	public async Task<IHttpActionResult> Delete(Payment m)
	{
		return Ok(m);
	}
}
public class GoalController : ApiController
{
	public async Task<IHttpActionResult> Get()
	{
		return Ok(new List<Goal>());
	}
	public async Task<IHttpActionResult> GetById(int id)
	{
		return Ok(default(Goal));
	}
	[HttpPost]
	public async Task<IHttpActionResult> Search(string query)
	{
		return Ok(new List<Goal>());
	}
	[HttpPost]
	public async Task<IHttpActionResult> AddOrUpdate(Goal m)
	{
		return Ok(m);
	}
	public async Task<IHttpActionResult> DeleteById(int id)
	{
		return Ok(default(Goal));
	}
	[HttpPost]
	public async Task<IHttpActionResult> Delete(Goal m)
	{
		return Ok(m);
	}
}
 
