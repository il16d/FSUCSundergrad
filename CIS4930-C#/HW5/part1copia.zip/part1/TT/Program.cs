﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Json;
using System.Threading.Tasks;
using System.IO;

namespace TT
{
    class Program
    {
        static void Main(string[] args)
        {
            var data = System.Runtime.Remoting.Messaging.CallContext.GetData("AllModals");
            //string fileContent = File.ReadAllText(@"sample.txt");

            //foreach (string modal in fileContent.Split(new char[] { '}' }, StringSplitOptions.RemoveEmptyEntries))
            //{
            //    string modalName = modal.Substring(0, modal.IndexOf(':'));
            //    string jsonString = modal.Substring(modal.IndexOf('{')) + "}";
            //    Console.WriteLine(modalName);
            //    //Console.WriteLine(jsonString);
            //    JsonValue jsonObj = JsonObject.Parse(jsonString);
            //    foreach (KeyValuePair<string, JsonValue> v in jsonObj)
            //    {
            //        Console.WriteLine(v.Key + ":" + v.Value.ToString());
            //    }
            //}


            //RuntimeTextTemplate1 tt = new RuntimeTextTemplate1();
            //tt.Session = new Dictionary<string, object>();
            //tt.Session["FileName"] = "sample.txt";
            //tt.Initialize();
            //string outp = tt.TransformText();
            //TextTransform

        }
    }
}
