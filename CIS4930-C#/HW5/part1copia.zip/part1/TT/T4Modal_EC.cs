﻿using System;
using System.Collections.Generic;

public class ModelsBill_EC
{
	public List<ModelsBill> Get()
	{
		return new List<ModelsBill>();
	}
	public  ModelsBill GetById(int id)
	{
		return default(ModelsBill);
	}
	public List<ModelsBill> Search(string query)
	{
		return new List<ModelsBill>();
	}
	public ModelsBill AddOrUpdate(ModelsBill m)
	{
		return m;
	}
	public ModelsBill DeleteById(int id)
	{
		return default(ModelsBill);
	}
	public void Delete(ModelsBill m)
	{
	}
}
public class Payment_EC
{
	public List<Payment> Get()
	{
		return new List<Payment>();
	}
	public  Payment GetById(int id)
	{
		return default(Payment);
	}
	public List<Payment> Search(string query)
	{
		return new List<Payment>();
	}
	public Payment AddOrUpdate(Payment m)
	{
		return m;
	}
	public Payment DeleteById(int id)
	{
		return default(Payment);
	}
	public void Delete(Payment m)
	{
	}
}
public class Goal_EC
{
	public List<Goal> Get()
	{
		return new List<Goal>();
	}
	public  Goal GetById(int id)
	{
		return default(Goal);
	}
	public List<Goal> Search(string query)
	{
		return new List<Goal>();
	}
	public Goal AddOrUpdate(Goal m)
	{
		return m;
	}
	public Goal DeleteById(int id)
	{
		return default(Goal);
	}
	public void Delete(Goal m)
	{
	}
}
 
