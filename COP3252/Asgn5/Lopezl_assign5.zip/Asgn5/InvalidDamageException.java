public class InvalidDamageException extends Exception {
  public InvalidDamageException() {}
}
