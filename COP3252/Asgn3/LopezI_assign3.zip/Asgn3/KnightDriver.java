/**
 * Lopez Tobi, Iho
 * COP-3252
 * Assignment 3
 * Date January 24th 2020
 * Driver class
 */



public class KnightDriver {
	
    
        
        public static void main(String[] args)
        {
            
            System.out.println("Welcome to Camelot!\n");
           
            Knight knight = new Knight();
          
            knight.getUserInput();
            knight.PopupOutput();
            knight.exit();
            System.out.println("Already I am going to clean the table!\n");
            
        } // end main
    

}
