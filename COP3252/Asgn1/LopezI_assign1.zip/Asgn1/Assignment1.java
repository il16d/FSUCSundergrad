/*

López Tobi, Iho
COP-3252
Assignment 1
 Date: January 6th 2020

*/

public class Assignment1

{

  // My main method

  public static void main(String[] args)

  {

    System.out.println("Welcome to COP-3252 Java Programming!");

  }

}


