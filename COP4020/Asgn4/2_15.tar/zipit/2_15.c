
#include <stdio.h>

void parse_2_15(char *filename);

int main(int argc, char *argv[])
{
  if(argc > 1)
    {
      parse_2_15(argv[1]);
    }
}
