
#ifndef EMIT
#define EMIT

typedef enum 
  { 
    assign,                   // a(n) = e(-1)

    allocate_a,               
    allocate_e,
    allocate_e_in,
    allocate_e_out,
    allocate_e_constant,

    deallocate_a,
    deallocate_e,

    copy_e_a,                // e(-1) = a(n)
    copy_e_e,                // e(-k) = e(-j)
    dup_e,                   // push(e(-k))

    function_invocation,
    function_prologue,
    function_epilogue,

    boolean_assert,          // check e(-1); if false, then goto label
    boolean_assert_failed,   // 
    goto_,
    label
  } 

  instruction;

void emit(instruction,...);
char *new_label(void);

#endif
