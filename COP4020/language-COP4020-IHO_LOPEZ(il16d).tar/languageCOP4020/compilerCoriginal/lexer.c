#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <regex.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdarg.h>

#include "lexer.h"



int linecount = 1;
int charcount = 0;
char *current_token = NULL;
char *next_token = NULL;

char *consume(void);

void reset()
{
  linecount = 1;
  charcount = 0;
  current_token = consume();
  next_token = consume();
}


int try_lookahead(char *wanted)
{
  regex_t regex_wanted;

  // add boundaries to make sure that we are not doing a substring match  
  int length = strlen(wanted);
  char *bounded = (char *)malloc(length+3);
  strcpy(bounded+1,wanted);
  bounded[0] = '^';
  bounded[length+1] = '$';
  bounded[length+2] = '\0';

  if(next_token == NULL)
    {
      printf("Out of data\n");
      return(0);
    }

  int ret = regcomp(&regex_wanted,bounded,REG_EXTENDED|REG_NOSUB|REG_NEWLINE);
  if(ret != 0)
    {
      fail("lexer try_lookahead: Did not compile regex '%s'!\n",wanted);
    }

  if(regexec(&regex_wanted,next_token,0,NULL,0) == 0)
    {
      return(1);
    }

  regfree(&regex_wanted);
  free(bounded);

  return(0);
}


int try_match(char *wanted)
{
  regex_t regex_wanted;

  if(current_token == NULL)
    {
      printf("Out of data\n");
      return(0);
    }

  // add boundaries to make sure that we are not doing a substring match  
  int length = strlen(wanted);
  char *bounded = (char *)malloc(length+3);
  strcpy(bounded+1,wanted);
  bounded[0] = '^';
  bounded[length+1] = '$';
  bounded[length+2] = '\0';


  int ret = regcomp(&regex_wanted,bounded,REG_EXTENDED|REG_NOSUB|REG_NEWLINE);
  if(ret != 0)
    {
      fail("lexer try_match: Did not compile regex '%s'!\n",wanted);
    }

  if(regexec(&regex_wanted,current_token,0,NULL,0) == 0)
    {
      return(1);
    }

  regfree(&regex_wanted);
  free(bounded);

  return(0);
}


void must_match(char *wanted)
{
  if(!try_match(wanted))
    {
      fail("lexer --- match for tag '%s' failed, current_token is '%s'",wanted,current_token);
    }
  advance();
}

void advance()
{
  current_token = next_token;
  next_token = consume();
}


char *consume(void)
{
  char c;
  char buffer[256];

  // skip over whitespace and comments

  while((c = getchar()))
    {
      if(c == EOF)
	{
	  return(NULL);
	}
      if(c == ' ')
	{
	  charcount++;
	  continue;
	}
      if(c == '\t')
	{
	  charcount++;
	  continue;
	}
      if(c == '\n')
	{
	  linecount++;
	  charcount = 1;
	  continue;
	}
      
      // check for comment starting
      if(c == '#')
	{
	  while( (c = getchar()) != '\n' )
	    {
	    }
	  linecount++;
	  charcount = 1;
	}
      else
	// no comment means that we found lexically significant character
	break;
    }

  // okay, we have found something lexically significant
  // use the handy fact that a single-char sigil is enough to distinguish these

  int count = 0;

  switch(c)
    {
      
      // the one character cases
    case '{':
    case '}':
    case '(':
    case ')':
    case '=':
    case ',':
    case ';':
      // if any of these are the non-whitespace first character, then make it the token
      buffer[0] = c;
      buffer[1] = '\0';
      return(strdup(buffer));
      break;
      
      // is this the beginning of a string?
    case '"':

      buffer[0] = '"';
      count = 1;
      charcount++;

      while( (c = getchar()) != '"' )
	{
	  if(count == 256)
	    {
	      fail("lexer --- string too long!");
	    }
	  buffer[count++] = c;
	  if(c == '\n')
	    {
	      linecount++;
	      charcount = 1;
	    }
	  else
	    {
	      charcount++;
	    }
	}
      buffer[count] = '\0';
      return(strdup(buffer));
      break;
      
    default:
      
      // it's something else lexically significant
      buffer[0] = c;
      count = 1;
      if(isalpha(c) || c == '_')
	{
	  // starting alpha, read until it's not
          while((c = getchar()))
	    {
	      if(isalpha(c) || isdigit(c) || c == '_' || c == '.')
		{
		  buffer[count++] = c;
		  charcount++;
		}
	      else
		{
		  buffer[count] = '\0';
		  ungetc(c,stdin);
		  charcount--;
		  break;
		}
	    }
	  return(strdup(buffer));
	}
      if(isdigit(c) || c == '-')
	{
	  // starting a number, read until find non-digit
	  while((c = getchar()))
	    {
	      if(isdigit(c))
		{
		  buffer[count++] = c;
		  charcount++;
		}
	      else
		{
		  buffer[count] = '\0';
		  ungetc(c,stdin);
		  charcount--;
		  break;
		}
	    }
	  return(strdup(buffer));
	}
      if(c == ';')
	{
	  buffer[1] = '\0';
	  charcount++;
	  return(strdup(buffer));
	}
      fail("lexer --- not sure what to make of this; it's not a comment, string, identifier, or integer");
      break;
    }
  fail("lexer --- not sure what to make of this; got to the end of a void function!");
  return(NULL);
}


void fail(char *string, ...)
{
  va_list args;
  va_start(args,string);
  fprintf(stderr,"at line %d, char position %d: ",linecount,charcount);
  vfprintf(stderr,string,args);
  fprintf(stderr,"\n");
  va_end(args);
  exit(1);
}
