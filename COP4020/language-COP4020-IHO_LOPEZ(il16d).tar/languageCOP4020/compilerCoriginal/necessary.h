#ifndef NECESSARY

#define NECESSARY

#include <stdbool.h>

// list visible structs and functions
struct name_value_pair
{
  char *name;
  char *value;
  struct name_value_pair *next;
  struct name_value_pair *prev;
};

typedef struct name_value_pair name_value_pair;

struct list
{
  char *name;
  long count; // don't ask; clang gives a warning if not 8-byte aligned!
  name_value_pair *first;
  name_value_pair *last;

  void (*insert)(struct list *, char *name, char *value);
  void (*insert_count)(struct list *, int count, char *name, char *value);
  name_value_pair *(*search)(struct list *, char *name);
  int  (*count_from_top)(struct list *, char *name);
  void (*remove_last)(struct list *, int count);
  void (*destroy)(struct list *);
  void (*print)(struct list *);
};

typedef struct list *list;


// active variable structs and functions
struct active_variable
{
  char *name;
  int scope_number;
  bool used;
  struct active_variable *next;
  struct active_variable *prev;
};
struct active_variable_list
{
  char *name;
  long count; // don't ask; clang gives a warning if not 8-byte aligned!
  struct active_variable *first;
  struct active_variable *last;

  void (*add)(struct active_variable_list *, char *name, int scope_number, bool used);
  struct active_variable *(*search_name)(struct active_variable_list *, char *name);
  struct active_variable *(*search_name_scope)(struct active_variable_list *, char *name, int scope_number);
  int (*count_scope)(struct active_variable_list *, int scope_number);
  int (*count_from_top)(struct active_variable_list *, char *name);
  void (*delete_scope)(struct active_variable_list *, int scope_number);
  void (*destroy)(struct active_variable_list *);
  void (*print)(struct active_variable_list *);
};

typedef struct active_variable_list *active_variable_list;

active_variable_list active_variable_list_create(char *);


// known function structs and functions

struct known_function
{
  int out_arity;
  int in_arity;
  bool defined;
};


void known_functions_insert(char *name,int out_arity,int in_arity,bool defined);
void known_functions_set_defined(char *name);
bool known_functions_search(char *name);
struct known_function *known_functions_get(char *name);
void known_functions_list();


char *catenate(char *string1, char *string2);



struct dictionary
{
  char *name;
  long count;
  name_value_pair *entries;

  bool (*exists)(struct dictionary *,char *);
  char *(*get)(struct dictionary *,char *);
  void (*set)(struct dictionary *,char *,char *);
  void (*insert)(struct dictionary *, char *, char *);
  void (*destroy)(struct dictionary *);
  void (*print)(struct dictionary *);
};

typedef struct dictionary *dictionary;

// visible functions
list list_create(char *name);
dictionary dictionary_create(char *name);
void fail(char *, ...);

#endif
