
#ifndef LEXER
#define LEXER

typedef enum 
  {
    // assignment
    ASSIGN,

    // numbers and identifiers
    NUMBER,
    IDENTIFIER,

    // punctuation
    LCURLYBRACE,
    RCURLYBRACE,
    LPAREN,
    RPAREN,
    SEMICOLON,
    COMMA,

    // keywords
    //    top-level keywords
    USES,
    EXPORTS,
    DECLARATIONS,
    PROGRAM,
    
    //    function, compound statement, and program environment
    VAR

  } component;



// int try_match(component tag);
int try_match(char *);
int try_lookahead(char *);
// void must_match(component tag);
void must_match(char *);
void advance(void);
void fail(char *, ...);
void reset(void);

#endif
