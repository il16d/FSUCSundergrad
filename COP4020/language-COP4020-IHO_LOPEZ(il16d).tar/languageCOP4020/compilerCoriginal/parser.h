#ifndef PARSER
#define PARSER

void parse(char *);

#endif
