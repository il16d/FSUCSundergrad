
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>

#include "necessary.h"

#include "emit.h"

char *new_label()
{
  static int label_counter = 0;

  if(label_counter > 100000)
    fail("emit.c: new_label(): label counter exceeds 100000 (congratulations!)");

  char *ret = malloc(10);
  if(ret == NULL)
    fail("emit.c: new_label(): malloc() fails");

  snprintf(ret,10,"_l%06d",label_counter);
  label_counter++;
  
  return(ret);
}

void replace_period_with_underscore(char *s);


void emit(instruction i,...)
{
  va_list ap;
  va_start(ap,i);


  switch(i)
    {
    case assign:
      {
	int count = va_arg(ap, int) ;
	printf("assign(a,e,%d,1);\n",count);
      }
      break;
    case allocate_a:
      {
	int count = va_arg(ap, int) ;
	printf("a->allocate(a,%d);\n",count);
      }
      break;
    case allocate_e:
      {
	int count = va_arg(ap, int) ;
	printf("e->allocate_e(e,%d);\n",count);
      }
      break;
    case allocate_e_in:
      {
	int count = va_arg(ap, int) ;
	printf("e->allocate_in(e,%d);\n",count);
      }
      break;
    case allocate_e_constant:
      {
	char *arg = va_arg(ap, char *);
	printf("e->allocate_constant(e,\"%s\");\n",arg);
      }
      break;
    case allocate_e_out:
      {
	int count = va_arg(ap, int) ;
	printf("e->allocate_out(e,%d);\n",count);
      }
      break;
    case deallocate_a:
      {
	int count = va_arg(ap, int) ;
	printf("a->deallocate(a,%d);\n",count);
      }
      break;
    case deallocate_e:
      {
	int count = va_arg(ap, int) ;
	printf("e->deallocate(e,%d,1);\n",count);
      }
      break;
    case copy_e_a:
      {
	int where = va_arg(ap, int) ;
	printf("copy_to_evaluation(e,a,%d,1);\n",where);
      }
      break;
    case copy_e_e:
      {
	int target = va_arg(ap, int);
	int source = va_arg(ap, int);
	printf("e->copy_e_e(e,%d,%d,1);\n",target,source);
      }
      break;
    case dup_e:
      {
	int where = va_arg(ap, int);
	printf("e->dup(e,%d,1);\n",where);
      }
      break;
    case function_invocation:
      {
	char *function_name = va_arg(ap, char *) ;
	replace_period_with_underscore(function_name);
	char *label = new_label();
	printf("r->push(r,&&%s);\n",label);
	printf("goto %s;\n",function_name);
	printf("%s:\n",label);
	free(label);
      }
      break;
    case function_prologue:
      {
	char *function_name = va_arg(ap, char *) ;
	replace_period_with_underscore(function_name);
	printf("%s:   // function %s begins here\n",function_name,function_name);
      }
      break;
    case function_epilogue:
      {
	char *function_name = va_arg(ap, char *) ;
	replace_period_with_underscore(function_name);
	printf("goto *r->pop(r); // function %s ends here\n",function_name);
      }
      break;
    case boolean_assert:
      {
	char *failure_label = va_arg(ap, char *) ;
	printf("_p = e->deref(e,1);\n");
	printf("if((strcmp(_p,\"0\")==0)||(strcmp(_p,\"false\")==0)) goto %s;\n",failure_label);
	printf("e->deallocate(e,1,1);\n"); // in either case, have to remove expression value from evaluation stack
      }
      break;
    case boolean_assert_failed:
      {
	char *label = va_arg(ap, char *) ;
	printf("%s:\n",label);
	printf("e->deallocate(e,1,1);\n"); // in either case, have to remove expression value from evaluation stack
      }
      break;
    case label:
      {
	char *label = va_arg(ap, char *) ;
	printf("%s:\n",label);
      }
      break;
    case goto_:
      {
	char *label = va_arg(ap, char *) ;
	printf("goto %s;\n",label);
      }
      break;
    default:
      fprintf(stderr,"OOPSS --> received an emit for an unimplemented instruction!\n");
      fail("Received emit for an unimplemented instruction.");
      break;
    }
  va_end(ap);
}



// replace the period ('.') with an underscore ('_');
void replace_period_with_underscore(char *s)
{
  char *period_location = strchr(s,'.');
  if(period_location)
    *period_location = '_';
}
