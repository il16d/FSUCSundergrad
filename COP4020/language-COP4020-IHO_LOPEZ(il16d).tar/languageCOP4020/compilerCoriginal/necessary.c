
/*

  list

  dictionary

 */



#include <malloc.h>
#include <stdbool.h>
#include <string.h>
#include <Judy.h>

#include "necessary.h"




// declarations

static void list_insert(list l, char *name, char *value);
static void list_insert_count(list l, int count, char *name, char *value);
static name_value_pair *list_search(list l, char *name);
static int list_count_from_top(list l,char *name);
static void list_remove_last(list l, int count);
static void list_destroy(list l);
static void list_print(list l);

static void active_variable_list_add(active_variable_list avl, char *name, int scope_number, bool used);
static struct active_variable *active_variable_list_search_name(active_variable_list avl, char *name);
static struct active_variable *active_variable_list_search_name_scope(active_variable_list avl, char *name, int scope_number);
static int active_variable_list_count_scope(active_variable_list avl, int scope_number);
static int active_variable_list_count_from_top(active_variable_list avl, char *name);
static void active_variable_list_delete_scope(active_variable_list avl, int scope_number);
static void active_variable_list_destroy(active_variable_list avl);
static void active_variable_list_print(active_variable_list avl);
active_variable_list avl = NULL;


Pvoid_t known_functions = NULL;


static bool dictionary_exists(dictionary d, char *name);
static char *dictionary_get(dictionary d, char *name);
static void dictionary_set(dictionary d, char *name, char *value);
static void dictionary_insert(dictionary d, char *name, char *value);
static void dictionary_destroy(dictionary d);
static void dictionary_print(dictionary d);

// functions begin
list list_create(char *name)
{
  list ret = malloc(sizeof(struct list));
  if(ret == NULL)
    {
      fail("list_create: Cannot malloc");
    }

  ret->name = strdup(name);
  ret->count = 0;
  ret->first = NULL;
  ret->last = NULL;
  ret->insert = &list_insert;
  ret->insert_count = &list_insert_count;
  ret->search = &list_search;
  ret->count_from_top = &list_count_from_top;
  ret->remove_last = &list_remove_last;
  ret->destroy = &list_destroy;
  ret->print = &list_print;

  return(ret);
}

static void list_insert(list l, char *name, char *value)
{
  l->count++;

  name_value_pair *new = malloc(sizeof(name_value_pair));
  if(new == NULL)
    fail("necessary.c list_insert cannot malloc!");
  new->next = NULL;
  new->prev = NULL;
  new->name = strdup(name);
  if(value)
    new->value = strdup(value);
  else
    new->value = NULL;

  if(l->last == NULL)
    {
      l->first = new;
      l->last = new;
    }
  else
    {
      new->prev = l->last;
      l->last->next = new;
      l->last = new;
    }
}

static void list_insert_count(list l, int count, char *name, char *value)
{
  int i;
  for(i=0; i<count; i++)
    l->insert(l,name,value);
}


static struct name_value_pair *list_search(list l, char *name)
{
  name_value_pair *ptr;
  for(ptr = l->first; ptr; ptr=ptr->next)
    {
      if(strcmp(ptr->name,name) == 0)
	{
	  return(ptr);
	}
    }
  return(NULL);
}

static int list_count_from_top(list l, char *name)
{
  int count = 0;
  struct name_value_pair *ptr;
  for(ptr = l->last; ptr; ptr=ptr->prev)
    {
      if(strcmp(ptr->name,name) == 0)
	{
	  return(count);
	}
      count++;
    }
  fail("necessary.c: list_count_from_top(): failed to find '%s' in list",name);
  return(-1);
}

static void list_remove_last(list l,int count)
{
  if((count > 0) && (l->last == NULL))
    fail("necessary.c: list_remove_last(): attempt to remove item from empty list");

  int i;
  for(i=0;i<count;i++)
    {
      name_value_pair *ptr = l->last;
      if(ptr == NULL)
	{
	  fail("necessary.c: list_remove_last(): attempt to remove item from empty list");
	}
      l->last = ptr->prev;

      if(l->last == NULL)
	l->first = NULL;
      else
	l->last->next = NULL;

      free(ptr->name);
      free(ptr->value);
      free(ptr); 
    }
}

static void list_destroy(list l)
{
  free(l->name);
  name_value_pair *ptr = l->first;
  while(ptr) 
    {
      name_value_pair *pptr = ptr->next;
      free(ptr->name);
      free(ptr->value);
      free(ptr);
      ptr = pptr;
    }
  free(l);
}

static void list_print(list l)
{
  fprintf(stderr,"List '%s'\n",l->name);
  fprintf(stderr,"List items == %ld\n",l->count);
  fprintf(stderr,"====\n");
  name_value_pair *ptr;
  for(ptr=l->first; ptr; ptr=ptr->next)
    {
      fprintf(stderr,"\t\t%p) %s : %s ; next = %p, prev = %p\n",
	      ptr,
	      ptr->name,
	      ptr->value,
	      ptr->next,
	      ptr->prev);
    }
  fprintf(stderr,"====\n");
  fprintf(stderr,"\n");
}

/*    ACTIVE VARIABLE LIST   */

active_variable_list active_variable_list_create(char *name)
{
  active_variable_list avl = (active_variable_list)malloc(sizeof(struct active_variable_list));
  if(avl == NULL)
    fail("necessary.c: active_variable_list_create(): cannot malloc");
  avl->name = strdup(name);
  avl->count = 0;
  avl->first = NULL;
  avl->last = NULL;
  avl->add = &active_variable_list_add;
  avl->search_name = &active_variable_list_search_name;
  avl->search_name_scope = &active_variable_list_search_name_scope;
  avl->delete_scope = &active_variable_list_delete_scope;
  avl->count_scope = &active_variable_list_count_scope;
  avl->count_from_top = &active_variable_list_count_from_top;
  avl->destroy = &active_variable_list_destroy;
  avl->print = &active_variable_list_print;
  return(avl);
}

static void active_variable_list_add(active_variable_list avl, char *name, int scope_number, bool used)
{
  avl->count++;
  struct active_variable *av = (struct active_variable *)malloc(sizeof(struct active_variable));
  if(av == NULL)
    fail("necessary.c: active_variable_list_add_name(): cannot malloc");
  av->name = strdup(name);
  av->scope_number = scope_number;
  av->used = used;
  av->next = NULL;
  av->prev = NULL;
  if(avl->last)
    {
      av->prev = avl->last;
      avl->last->next = av;
      avl->last = av;
    }
  else
    {
      avl->first = av;
      avl->last = av;
    }
}
static struct active_variable *active_variable_list_search_name(active_variable_list avl, char *name)
{
  struct active_variable *ptr;
  for(ptr = avl->last; ptr; ptr = ptr->prev)
    {
      if(strcmp(ptr->name,name) == 0)
	return(ptr);
    }
  return(NULL);
}

static int active_variable_list_count_from_top(active_variable_list avl, char *name)
{
  int count = 0;
  struct active_variable *ptr;
  for(ptr = avl->last; ptr; ptr=ptr->prev)
    {
      if(strcmp(ptr->name,name) == 0)
	{
	  return(count);
	}
      count++;
    }
  fail("necessary.c: count_from_top(): failed to find '%s' in the active variable list",name);
  return(-1);
}


static struct active_variable *active_variable_list_search_name_scope(active_variable_list avl, char *name, int scope_number)
{
  struct active_variable *ptr;
  for(ptr = avl->last; ptr; ptr = ptr->prev)
    {
      if( (ptr->scope_number == scope_number) && (strcmp(ptr->name,name) == 0) )
	return(ptr);
    }
  return(NULL);
}

static int active_variable_list_count_scope(active_variable_list avl, int scope_number)
{
  int ret = 0;

  struct active_variable *ptr;
  for(ptr = avl->first; ptr ; ptr=ptr->next)
    {
      if(ptr->scope_number == scope_number)
	ret++;
    }

  return(ret);
}

static void active_variable_list_delete_scope(active_variable_list avl, int scope_number)
{
  struct active_variable *ptr = avl->last;
  while(ptr)
    {
      struct active_variable *pptr = ptr->prev;
      if(ptr->scope_number == scope_number)
	{
	  avl->last = pptr;
	  if(pptr == NULL)
	    avl->first = NULL;

	  avl->count--;
	  if(ptr->prev)
	    ptr->prev->next = NULL;

	  free(ptr->name);
	  free(ptr); 
	}
      else
	return;
      ptr = pptr;
    }
}
static void active_variable_list_destroy(active_variable_list avl)
{
  free(avl->name);
  struct active_variable *ptr = avl->first;
  while(ptr)
    {
      struct active_variable *nptr = ptr->next;
      free(ptr->name);
      free(ptr); 
      ptr = nptr;
    }
}
static void active_variable_list_print(active_variable_list avl)
{
  fprintf(stderr,"Active variable list '%s':\n",avl->name);
  fprintf(stderr,"==========================\n");
  fprintf(stderr,"Count = %ld\n",avl->count);
  struct active_variable *ptr = avl->first;
  if(ptr)
    {
      for( ; ptr ; ptr = ptr->next)
	{
	  fprintf(stderr,"   scope %d : '%s', has been used = %s\n",
		  ptr->scope_number,
		  ptr->name,
		  ptr->used == true ? "true" : "false");
	}
    }
  else
    {
      fprintf(stderr," [ EMPTY LIST ]\n");
    }
}

/*   KNOWN FUNCTIONS   */

void known_functions_insert(char *name,int out_arity,int in_arity,bool defined)
{
}

bool known_functions_search(char *name)
{
  PWord_t PValue;
  JSLG(PValue,known_functions,(unsigned char *)name);
  if(PValue != NULL)
    {
      return(true);
      //      f = (struct known_function *)*PValue;
    }

  return(false);
}

struct known_function *known_functions_get(char *name)
{
  PWord_t PValue;
  JSLG(PValue,known_functions,(unsigned char *)name);
  return((struct known_function *)*PValue);
}

void known_functions_set_defined(char *name)
{
  PWord_t PValue;
  int done;
  struct known_function *f;

  f = (struct known_function *)(malloc(sizeof(struct known_function)));
  if(!f)
    fail("necessary.c: known_functions_set_defined(): cannot malloc");

  JSLG(PValue,known_functions,(unsigned char *)name);
  f->in_arity = ((struct known_function*)(*PValue))->in_arity;
  f->out_arity = ((struct known_function*)(*PValue))->out_arity;
  f->defined = true;
  free((void *)*PValue);

  JSLD(done,known_functions,(unsigned char *)name);
  if(!done)
    fail("necessary.c: known_functions_set_defined(): cannot delete function %s",name);

  JSLI(PValue,known_functions,(unsigned char *)name);
  *PValue = (unsigned long)f;
  
}

void known_functions_list()
{
  // list known functions

  uint8_t name[256];

  fprintf(stderr,"Known functions:\n");
  name[0] = '\0';
  struct known_function *f;
  PWord_t PValue;

  JSLF(PValue,known_functions,name);
  while(PValue)
    {
      f = (struct known_function *)*PValue;
      fprintf(stderr,"\t(%d) = %s(%d), defined = %s\n",
	      (f)->out_arity,
	      name,
	      (f)->in_arity,
	      (f)->defined ? "true" : "false");
      JSLN(PValue,known_functions,name);
    }
}

/*   others  */

char *catenate(char *string1, char *string2)
{
  int string_size = strlen(string1) + strlen(string2) + 1;

  char *name = (char *)malloc(string_size);
  if(name == NULL)
    fail("parser.c: catenate: malloc fails for %s + %s",string1,string2);

  strcpy(name,string1);
  strcat(name,string2);

  return(name);
}



/*   DICTIONARY    */


dictionary dictionary_create(char *name)
{
  dictionary ret = malloc(sizeof(struct dictionary));
  if(ret == NULL)
    {
      fail("dictionary_create: Cannot malloc");
    }

  ret->name = strdup(name);
  ret->count = 0;
  ret->entries = NULL;

  ret->exists = &dictionary_exists;
  ret->get = &dictionary_get;
  ret->set = &dictionary_set;
  ret->insert = &dictionary_insert;
  ret->destroy = &dictionary_destroy;
  ret->print = &dictionary_print;

  return(ret);
}

static bool dictionary_exists(dictionary d, char *name)
{
  name_value_pair *entry;
  for(entry = d->entries; entry != NULL; entry=entry->next)
    {
      if(strcmp(name,entry->name) == 0)
	{
	  return(true);
	}
    }

  return(false);
}

static char *dictionary_get(dictionary d, char *name)
{
  name_value_pair *entry;
  for(entry = d->entries; entry != NULL; entry=entry->next)
    {
      if(strcmp(name,entry->name) == 0)
	{
	  return(entry->value);
	}
    }

  return(NULL);
}

static void dictionary_set(dictionary d, char *name, char *value)
{
  name_value_pair *entry;
  for(entry = d->entries; entry != NULL; entry=entry->next)
    {
      if(strcmp(name,entry->name) == 0)
	{
	  entry->value = strdup(value);
	  return;
	}
    }

  return;
}

static void dictionary_insert(dictionary d, char *name, char *value)
{
  name_value_pair *entry = malloc(sizeof(name_value_pair));
  if(entry == NULL)
    {
      fail("dictionary_insert: malloc failed");
    }
  entry->name = strdup(name);
  entry->value = strdup(value);
  entry->next = d->entries;
  d->entries = entry;

  return;
}

static void dictionary_destroy(dictionary d)
{
  free(d->name);
  name_value_pair *p;
  for(p=d->entries; p; )
    {
      name_value_pair *pp = p->next;
      free(p->name);
      free(p->value);
      free(p);
      p = pp;
    }
  free(d);

  return;
}

static void dictionary_print(dictionary d)
{
  printf("Dictionary '%s'\n",d->name);
  printf("==========\n");

  name_value_pair *p;
  for(p=d->entries; p; p=p->next)
    {
      printf("\t\t%s : %s\n",p->name,p->value);
    }
  printf("==========\n");
}



