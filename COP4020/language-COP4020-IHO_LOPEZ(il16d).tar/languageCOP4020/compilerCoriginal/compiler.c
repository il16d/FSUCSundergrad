#include <unistd.h>
#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "parser.h"

void usage(char *,...);

int main(int argc, char **argv)
{
  char *output_file = "out.c";
  int opt;
  
  while((opt = getopt(argc, argv, "o:")) != -1)
    {
      switch(opt)
	{
	case 'o':
	  output_file = strdup(optarg);
	  break;
	default:
	  usage("");
	  break;
	}
    }

  if(output_file && freopen(output_file,"w",stdout))
    {
      for(; optind < argc; optind++)
	{
	  fprintf(stderr,"parsing %s\n",argv[optind]);
	  parse(argv[optind]);
	}
    }
  else
    {
      usage("Cannot open output file '%s'",output_file);
    }
}

void usage(char *string, ...)
{
  va_list args;
  va_start(args,string);
  vfprintf(stderr,string,args);
  fprintf(stderr,"Usage: compiler [-o outputfile] [libs] program\n");
  fprintf(stderr,"\n");
  va_end(args);
  exit(1);
}
