
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdbool.h>
#include <string.h>
#include <Judy.h>

#include "lexer.h"
#include "parser.h"
#include "emit.h"
#include "necessary.h"

// data and data structures

extern Pvoid_t known_functions;

// active variable list, the parameter list
extern active_variable_list avl;
list active_parameter_list;


int current_scope_number = -1;                 // how deep are we in the current lexical structure?


// Our recursive descent functions

// decider
void main_or_module_or_exports(void);
// void program_or_module(void);

// unique to main
void program_section(void);

// unique to library
void exports_section(void);

// common to both
void imports_section(void);        // remove imports; it seems to be superfluous
void declarations_section(void);
void module_list(void);
//      functions
void functions_section(void);
void function(void);
void function_list(void);
void function_declaration(void);
void function_declaration_list(void);
//      statements
void variable_declaration(void);
void assignment_statement(void);
void if_else_statement(void);
void while_statement(void);
void statement_block(void);
void statement_list(void);
//      expressions
int expression(void);         // returns the net arity of the expression
void argument(void);
int argument_list(void);      // returns the total arity of the arguments
int function_call(void);      // returns the net arity of the function call
list identifier_list(void);
//      function list

// utilities
void list_known_functions(void);
char *catenate(char *string1, char *string2);


char *identifier = "[a-zA-Z][a-zA-Z0-9._]*";
char *number = "([0-9]+)|(-[0-9]+)";

extern char *current_token;
extern char *next_token;

char *current_module_name = NULL;

void parse(char *file)
{
  if(freopen(file,"r",stdin) == NULL)
    {
      fprintf(stderr,"Failed to open input file '%s'\n",file);
      return;
    }

  // set the module name
  if(current_module_name)
    free(current_module_name);
  current_module_name = NULL;

  reset(); // reset the lexer state
  if(!avl)
    {
      avl = active_variable_list_create("Active variables");
    }

  main_or_module_or_exports();
  fprintf(stderr,"Recognized %s!\n",file);
}


void main_or_module_or_exports()
{
  if(try_match("main"))
    {
      // syntax
      advance();           // consume "main" 
      current_module_name = "main";
      declarations_section();
      program_section();
      functions_section();
      //
    }
  else if(try_match("module"))
    {
      // syntax
      advance();          // consume "module"
      current_module_name = strdup(current_token);
      must_match(identifier);
      if(try_match("exports"))
	{
	  exports_section();
	}
      else if(try_match("imports"))
	{
	  imports_section();
	  declarations_section();
	  functions_section();
	}
      //
    }
}


// sections


void imports_section()
{
  // syntax
  must_match("imports");
  must_match("[{]");
  module_list();
  must_match("[}]");
  //
}


void module_list(void){
  while(!try_match("[}]"))
    {
      // syntax
      must_match(identifier);
      must_match(";");
      //
    }
}

void program_section()
{
  // semantics
  active_parameter_list = list_create("active parameter list for main");
  emit(label,"_main");
  //

  // syntax
  must_match("program");
  statement_block();
  //

  // semantics
  emit(goto_,"_exit");
  active_parameter_list->destroy(active_parameter_list);
  active_parameter_list = NULL;

}

void statement_list()
{
  // syntax (mostly)
  while(!try_match("[}]"))
    {
      if(try_match("var"))
	{
	  variable_declaration();
	}
      else if(try_match("[{]"))
	{
	  statement_block();
	}
      else if(try_match("if"))
	{
	  if_else_statement();
	}
      else if(try_match("while"))
	{
	  while_statement();
	}
      else if(try_match("[(]"))
	{
	  assignment_statement();  // this is an assignment statement that begins with an identifier list
	}
      else if(try_match(identifier))
	{
	  if(try_lookahead("[(]"))
	    {
	      int how_many = function_call();
	      must_match(";");

	      // semantics
	      emit(deallocate_e, how_many); // if the statementis is just a call to
                                            // a function (for its side-effect, presumably),
                                            //  the evaluation stack needs to be cleared
	      active_parameter_list->remove_last(active_parameter_list,how_many);
	      //
	    }
	  else if(try_lookahead("="))
	    {
	      assignment_statement();
	    }
	  else
	    {
	      fail("statement_list: expected a statement");
	    }
	}
      else
	{
	  fail("statement_list: expected a statement");
	}
    }
  //
}

void functions_section()
{
  // syntax
  must_match("functions");
  must_match("[{]");
  function_list();
  must_match("[}]");
  //
}

void function_list()
{
  // syntax
  while(!try_match("[}]"))
    {
      function();
    }
  //
}

void function_declaration_list()
{
  // syntax
  while(!try_match("[}]"))
    {
      function_declaration();
    }
  //
}

void function_declaration()
{

  // syntax
  must_match("[(]");
  list out = identifier_list();
  must_match("[)]");
  must_match("=");
  //

  // semantics
  char *dot_token = catenate(current_module_name,".");
  char *name = catenate(dot_token,current_token);
  free(dot_token);
  //

  // syntax
  must_match(identifier);
  must_match("[(]");
  list in = identifier_list();
  must_match("[)]");
  must_match(";");
  //

  // semantics --> add this function declaration to the dictionary of known functions

  // FIXME: this should be in a separate function
  struct known_function *f = malloc(sizeof(struct known_function));
  if(!f)
    fail("parser.c: function_declaration(): failed to malloc()");
  f->out_arity = out->count;
  f->in_arity = in->count;
  f->defined = false;

  PWord_t PValue; // Add the current_module_name
  JSLI(PValue,known_functions,(unsigned char *)name);
  if(f == PJERR)
    fail("parser.c: function_declaration(): Judy array insert failed");
  *PValue = (unsigned long)f;
  //
}

void exports_section()
{
  // syntax
  must_match("exports");
  must_match("[{]");
  function_declaration_list();
  must_match("[}]");
  //
}

void declarations_section()
{
  // syntax
  must_match("declarations");
  must_match("[{]");
  function_declaration_list();
  must_match("[}]");
  //
}

void variable_declaration()
{
  // syntax
  must_match("var");
  //

  // semantics
  int identifier_count;
  int singleton = 0;
  char *name = NULL;
  list l = NULL;
  //

  // syntax (mostly)
  if(try_match(identifier))
    {
      // semantics
      name = strdup(current_token);
      identifier_count = 1;
      singleton = 1;
      //

      advance();
    }
  else
    {
      must_match("[(]");
      l = identifier_list();
      must_match("[)]");

      // semantics
      identifier_count = l->count;
      //
    }

  // syntax
  must_match("=");
  int expression_out_arity = expression(); 
  must_match(";");
  //

  // semantics

  // arity check
  if(identifier_count != expression_out_arity)
    {
      fail("parser.c: variable declaration is for %d identifiers, but the expression has %d out arity",
	   identifier_count,
	   expression_out_arity);
    }

  // are the names already defined in this context?

  if(singleton)
    {
      struct active_variable *av = avl->search_name_scope(avl,name,current_scope_number);
      if(av)
	fail("parser.c: variable_declaration(): redefinition of variable '%s' in same scope",name);
    }
  else
    {
      name_value_pair *nvp = l->first;
      for(;nvp;nvp=nvp->next)
	{
	  struct active_variable *av = avl->search_name_scope(avl,nvp->name,current_scope_number);
	  if(av)
	    fail("parser.c: variable_declaration(): redefinition of variable '%s' in same scope",nvp->name);
	}
    }

  // okay, we need to define it/them

  if(singleton)
    {
      avl->add(avl,name,current_scope_number,false);
      emit(allocate_a,1);
      emit(assign,1);
      emit(deallocate_e,1);
      active_parameter_list->remove_last(active_parameter_list,1);
    }
  else
    {
      name_value_pair *nvp = l->last;
      for(;nvp;nvp=nvp->prev)
	{
	  avl->add(avl,nvp->name,current_scope_number,false);
	  emit(allocate_a,1);
	  emit(assign,1);
	  emit(deallocate_e,1);
	  active_parameter_list->remove_last(active_parameter_list,1);
	}
    }


  // don't forget to deallocate l if it exists
  if(l) 
    l->destroy(l);
  if(name)
    free(name);

  //
}

// expressions return the net number of items left on the evaluation stack
int expression()
{
  // syntax (mostly)
  if(try_match(number))
    {
      emit(allocate_e_constant,current_token);

      // semantics
      active_parameter_list->insert(active_parameter_list,"anonymous number constant",current_token);
      //

      advance();
      return(1);
    }
  else if(try_match("\".*"))
    {
      emit(allocate_e_constant,current_token+1);

      // semantics
      active_parameter_list->insert(active_parameter_list,"anonymous string constant",current_token+1);
      //

      advance();
      return(1);
    }
  else if(try_match(identifier))
    {
      if(try_lookahead("[(]"))
	{
	  int ret = function_call();
	  return(ret);
	}
      else
	{

	  // semantics
	  int where = 0;
	  int found = 0;
	  if(avl->search_name(avl,current_token))
	    {
	      found = 1;
	      where = avl->count_from_top(avl,current_token);
	      emit(copy_e_a,where+1);
    	      active_parameter_list->insert(active_parameter_list,"(anonymous copy of variable)",current_token);
	    }
	  if(!found &&
	     active_parameter_list->search(active_parameter_list,current_token))
	    {
	      found = 2;
	      where = active_parameter_list->count_from_top(active_parameter_list,current_token);
	      emit(dup_e,where+1);
	      active_parameter_list->insert(active_parameter_list,"(anonymous copy of evaluation variable)",current_token);
	    }
	  //

	  advance();

	  return(1);
	}
    }
  else
    {
      fail("parser.c: expression(): That's not an expression");
    }
  fail("parser.c: expression(): fell through, shouldn't do that.");
  return(0);
}

// caller / callee:
//
// function caller does all of the stack manipulation
// 
// a function call leaves 0 or more items on the evaluation stack. these need to
// removed either at the end of an assignment, or if a function is called
// just as a statement (for its side-effects, one assumes)
// 
int function_call()
{
  // semantics
  char *function_name = strdup(current_token); // save the function's name
  //

  // syntax
  must_match(identifier); 
  //

  // semantics

  // once we have found the identifier, it's time to allocate the
  // "out" stack items on the evaluation stack, so go look those up
  // if there is no "." in the function name, add this module's
  if(!strchr(function_name,'.'))
    {
      char *module_with_dot = catenate(current_module_name,".");
      char *testname = catenate(module_with_dot,function_name);
      free(module_with_dot);
      free(function_name);
      function_name = testname;
    }

  if(!known_functions_search(function_name))
    {
      known_functions_list();
      fail("parser.c: function_call(): unknown function name %s",function_name);
    }

  struct known_function *f = known_functions_get(function_name);  

  emit(allocate_e_out,f->out_arity); // means allocate some number of out variables
  active_parameter_list->insert_count(active_parameter_list,f->out_arity,"out variable","");
  //


  // syntax
  must_match("[(]");
  int argcount = argument_list();        // argument list items will add to the stack
  must_match("[)]"); 
  //

  // semantics

  if(f->in_arity != argcount)
    {
      fail("parser.c: function call '%s' specifies an in arity of %d, but there are %d arguments in the argument list",function_name,f->in_arity,argcount);
    }

  emit(function_invocation, function_name);
  emit(deallocate_e, f->in_arity);
  active_parameter_list->remove_last(active_parameter_list, f->in_arity);

  return(f->out_arity); 
  //
}

void if_else_statement()
{
  // semantics
  char *else_block_start = new_label();
  char *else_block_end = new_label();
  //

  // syntax
  must_match("if");
  must_match("[(]");
  int arity = expression();  // FIXME: verify that arity == 1
  //

  // semantics
  emit(boolean_assert,else_block_start);
  active_parameter_list->remove_last(active_parameter_list,1); // the assert does a remove from evaluation stack
  //

  // syntax
  must_match("[)]");
  statement_block();
  //

  // semantics
  emit(goto_,else_block_end);
  emit(boolean_assert_failed,else_block_start); // failure of assertion comes here
                                                //  assert_failed also does handle clearing the evaluation 
                                                // stack of the expression value, but this list entry 
                                                // has already been removed when processing the true case
  //

  // syntax
  if(try_match("else"))
    {
      must_match("else");
      statement_block();
    }
  //
  
  // semantics
  emit(label,else_block_end);
}

void while_statement()
{
  // semantics
  char *statement_block_start = new_label();
  char *statement_block_exit = new_label();
  //

  // syntax
  must_match("while");
  must_match("[(]");
  //

  // semantics
  emit(label,statement_block_start);
  //

  // syntax
  int arity = expression();
  //

  // semantics
  if(arity != 1)
    fail("parser.c: while(): there should be one boolean item on the stack, but there are instead %d\n",arity);
  emit(boolean_assert,statement_block_exit); // where to go if a boolean check fails
  active_parameter_list->remove_last(active_parameter_list,1);
  //

  // syntax
  must_match("[)]");
  statement_block();
  //

  // semantics
  emit(goto_,statement_block_start);
  emit(label,statement_block_exit);
  emit(deallocate_e,1); // remove the evaluation when a boolean check fails
  //
}

// caller / callee
//
// callers do all of the set up and teardown; callees don't do any
//

void function()
{
  // syntax
  must_match("[(]");
  list params_out = identifier_list();    // these match names to places on the out part of the stack
  must_match("[)]");
  must_match("=");
  //

  // semantics
  char *function_name = strdup(current_token);

  //     make sure that the function has been already declared
  if(!strchr(function_name,'.'))
    {
      char *module_with_dot = catenate(current_module_name,".");
      char *testname = catenate(module_with_dot,function_name);
      free(module_with_dot);
      free(function_name);
      function_name = testname;
    }

  if(!known_functions_search(function_name))
    {
      known_functions_list();
      fail("parser.c: function_call(): there was no declaration in exports or declarations sections for this function %s",function_name);
    }

  known_functions_set_defined(function_name);
  emit(function_prologue,function_name);
  //

  // syntax
  must_match(identifier); 
  must_match("[(]");
  list params_in = identifier_list();    // these match names to places on the in part of the stack
  must_match("[)]");
  //

  // semantics
  active_parameter_list = list_create("active parameter list for function");
  struct name_value_pair *param;
  for(param = params_out->first; param ; param=param->next)
    {
      active_parameter_list->insert(active_parameter_list,param->name,"out");
    }
  for(param = params_in->first; param ; param=param->next)
    {
      active_parameter_list->insert(active_parameter_list,param->name,"in");
    }
  //

  // syntax
  statement_block();  // declarations inside a statement_block add to the activation stack
                      // and must be deallocated at the end
  //


  // semantics
  emit(function_epilogue,function_name);

  params_out->destroy(params_out);
  params_in->destroy(params_in);
  active_parameter_list->destroy(active_parameter_list);
  active_parameter_list = NULL;
  //
}

void assignment_statement()
{
  int identifier_count;
  list l = NULL;

  // syntax (mostly)
  if(try_match(identifier))
    {
      // semantics
      identifier_count = 1;
      l = list_create("identifier list");
      l->insert(l,current_token,"");
      //

      advance();
    }
  else
    {
      must_match("[(]");
      l = identifier_list();
      must_match("[)]");

      // semantics
      identifier_count = l->count;
      //
    }

  // syntax
  must_match("=");
  int expression_out_arity = expression(); 
  must_match(";");
  //


  // semantics

  // arity check
  if(identifier_count != expression_out_arity)
    {
      fail("parser.c: assignment is to %d identifiers, but the expression has %d out arity",
	   identifier_count,
	   expression_out_arity);
    }

  name_value_pair *id_list_nvp = l->last;
  for(;id_list_nvp;id_list_nvp=id_list_nvp->prev)
    {
      struct active_variable *av = avl->search_name(avl,id_list_nvp->name);
      if(av)
	{
	  int how_far = avl->count_from_top(avl,id_list_nvp->name);
	  emit(assign,how_far+1);
	  emit(deallocate_e,1);
	  active_parameter_list->remove_last(active_parameter_list,1);
	}
      else
	{
	  // check the parameters
	  struct name_value_pair *params_nvp = active_parameter_list->search(active_parameter_list,id_list_nvp->name);
	  if(params_nvp)
	    {
	      if(strcmp(params_nvp->value,"out") == 0)
		{
		  int how_far = active_parameter_list->count_from_top(active_parameter_list,id_list_nvp->name);
		  emit(copy_e_e,how_far+1,1);
		  emit(deallocate_e,1);
		  active_parameter_list->remove_last(active_parameter_list,1);
		}
	      else
		{
		  fail("parser.c: assignment(): variable '%s' refers to a non-out paramter",id_list_nvp->name);
		}
	    }
	  else
	    {
	      fail("parser.c: assignment(): variable '%s' not defined",id_list_nvp->name);
	    }
	}
    }


  if(l) 
    l->destroy(l);
}


list identifier_list()
{
  list l = list_create("identifier_list");

  // syntax (mostly)
  while(!try_match("[)]"))
    {
      l->insert(l,current_token,"");
      must_match(identifier);
      if(try_match("[)]"))
	{
	  // okay, don't need anything
	}
      else
	{
	  must_match(",");
	}
    }
  //

  return(l);
}

int argument_list()
{
  int arity_count = 0;

  // syntax (mostly)
  while(!try_match("[)]"))
    {
      arity_count += expression();
      if(try_match("[)]"))
	{
	  // okay, don't need anything
	}
      else
	{
	  must_match(",");
	}
    }
  //

  return(arity_count);
}


void statement_block()
{
  // syntax
  must_match("[{]");
  //

  // semantics
  current_scope_number++;
  //

  // syntax
  statement_list();
  must_match("[}]");
  //

  // semantics
  int active_count = avl->count_scope(avl,current_scope_number); // count how many are active
  avl->delete_scope(avl,current_scope_number);
  // must deallocate all activation variables from the activation stack for this scope
  if(active_count)
    emit(deallocate_a,active_count);

  current_scope_number--;
  //
}



