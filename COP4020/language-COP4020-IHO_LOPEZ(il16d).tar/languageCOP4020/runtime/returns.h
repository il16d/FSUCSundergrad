#include "variable.h"

#ifndef RETURNS
#define RETURNS

struct returns
{
  char *name;
  int max_size;
  int top;
  variable *stack;

  void (*push)(struct returns *, void *);
  void *(*pop)(struct returns *);

  void (*print)(struct returns *);
  void (*destroy)(struct returns *);
};

typedef struct returns *returns;
returns returns_create(char *, int);

#endif

