
// part of the run-time

#include "variable.h"

#ifndef EVALUATION
#define EVALUATION

struct evaluation
{
  char *name;
  int max_size;               // maxiumum number of elements in the evaluation stack
  int top;                    // where is the top of the stack?
  variable *stack;            // there are only variables in the stack

  // standard, used for variables that exist on the activation stack --> these
  // all make copies of the variables
  void (*push)(struct evaluation*,variable); // copy
  void (*pop)(struct evaluation*);           // destroy copy  
  void (*dup)(struct evaluation*, int which, int flag);
  void (*copy_e_e)(struct evaluation *,int target, int source, int flag);

  void (*allocate_out)(struct evaluation *, int count);
  void (*allocate_constant)(struct evaluation *, char *value);
  void (*deallocate)(struct evaluation *, int count, int flag);

  char *(*deref)(struct evaluation *, int count);
  
  // used for constant temporary variables that exist only on the evaluation stack as "in" variables
  variable (*allocate_and_push)(struct evaluation *,char *);
  void (*deallocate_and_pop)(struct evaluation *,int start, int end); // not sure this is correct?

  // scrunch the stack -- make sure that temporaries have first been deallocated
  void (*move)(struct evaluation *,int start, int end); // give the relative begin and end points of the "in" variables

  // utility
  void (*print)(struct evaluation *);
  void (*destroy)(struct evaluation *);
};

typedef struct evaluation *evaluation;

evaluation evaluation_create(char *, int);

#endif
