

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "evaluation.h"
#include "utility.h"

//declarations
static void evaluation_push(struct evaluation *evaluation, variable v);
static void evaluation_pop(struct evaluation *evaluation);
static void evaluation_dup(struct evaluation *e, int source, int flag);

static void evaluation_allocate_out(struct evaluation *evaluation, int count);
static void evaluation_allocate_constant(struct evaluation *evaluation, char *value);
static void evaluation_deallocate(struct evaluation *, int count, int flag);
static char *evaluation_deref(struct evaluation *, int which);
static void evaluation_copy_e_e(struct evaluation *, int target, int source, int flag);

static void evaluation_print(struct evaluation *evaluation);
static void evaluation_destroy(struct evaluation *evaluation);

// implementations
evaluation evaluation_create(char *name, int max)
{
  evaluation ret;

  ret = malloc(sizeof(struct evaluation));

  if(ret == NULL)
    {
      fail("evaluation_create: malloc() failed");
    }

  ret->name = strdup(name);
  ret->max_size = max;
  ret->top = 0;
  ret->stack = calloc(sizeof(struct variable),(size_t)max);

  if(ret->stack == NULL)
    {
      fail("evaluation_create: calloc() failed");
    }

  ret->push = &evaluation_push;
  ret->pop = &evaluation_pop;
  ret->dup = &evaluation_dup;
  ret->copy_e_e = &evaluation_copy_e_e;
  ret->allocate_out = &evaluation_allocate_out;
  ret->allocate_constant = &evaluation_allocate_constant;
  ret->deallocate = &evaluation_deallocate;

  ret->deref = &evaluation_deref;

  ret->print = &evaluation_print;
  ret->destroy = &evaluation_destroy;

  return(ret);
}

static void evaluation_push(struct evaluation *evaluation, variable v)
{
  if(evaluation->top < evaluation->max_size)
    {
      evaluation->stack[evaluation->top] = v;
      evaluation->top++;
    }
  else
    {
      fail("evaluation stack overflow!");
    }
}

static void evaluation_pop(struct evaluation *evaluation)
{
  if(evaluation->top)
    {
      variable v = evaluation->stack[evaluation->top-1];
      evaluation->top--;
      v->destroy(v);
    }
  else
    {
      fail("evalution.c: evaluation_pop(): evaluation stack underflows");
    }
}

/*
void (*boolean_assert)(struct evaluation *,void *)
{
  if(evaluation->top)
    {
      
    }
  else
    {
      fail("evalution.c: evaluation_pop(): evaluation stack underflows");
    }
} 
*/

// current, this means to create some new variables; however, it will probably
// end up that we just push NULL pointers
static void evaluation_allocate_out(struct evaluation *evaluation, int count)
{
  int i;
  for(i=0;i<count;i++)
    {
      variable v = variable_create("out variable",""); // probably wasteful
      evaluation->push(evaluation,v);
    }
}

static void evaluation_allocate_constant(struct evaluation *evaluation, char *value)
{
  variable v = variable_create("constant",value);
  evaluation->push(evaluation,v);
}

static void evaluation_deallocate(struct evaluation *evaluation, int count, int flag)
{
  int i;
  for(i=0;i<count;i++)
    {
      evaluation->pop(evaluation);
    }
}

static void evaluation_copy_e_e(struct evaluation *e, int target, int source, int flag)
{
  if( (target > e->top) || (source > e->top) )
    {
      fail("evaluation.c: evaluation_copy() attempts to underflow evaluation stack (e(%d) = e(%d))!",target,source);
    }

  // get rid of old target value
  variable old_v;
  old_v = e->stack[e->top-target];
  if(old_v)
    old_v->destroy(old_v);

  variable sourcev = e->stack[e->top-source];
  if(flag == 0)
    {
      e->stack[e->top-target] = sourcev;
    }
  else
    {
      e->stack[e->top-target] = sourcev->copy(sourcev);
    }
}

static void evaluation_dup(struct evaluation *e, int source, int flag)
{
  if( source > e->top )
    {
      fail("evaluation.c: evaluation_dup() attempts to underflow evaluation stack (push(e(%d)))!",source);
    }

  variable sourcev = e->stack[e->top-source];
  if(flag == 0)
    {
      e->push(e,sourcev);
    }
  else
    {
      e->push(e,sourcev->copy(sourcev));
    }
}

char *evaluation_deref(struct evaluation *evaluation, int which)
{
  // check validity
  if(which > evaluation->top)
    fail("attempt to deref beyond end of stack");
  return(evaluation->stack[evaluation->top - which]->value);
}

static void evaluation_print(struct evaluation *evaluation)
{
  int i;
  printf("Stack '%s'\n",evaluation->name);
  printf("  Maximum elements = %d\n",evaluation->max_size);
  printf("  Current elements = %d\n",evaluation->top);
  printf("  =====\n");
  for(i=0; i<evaluation->top; i++)
    {
      printf("  element %d: ",i);
      variable v = evaluation->stack[i];
      v->print(v);
      printf("\n");
    }
  printf("  =====\n");
}

static void evaluation_destroy(struct evaluation *evaluation)
{
  free(evaluation->name);
  free(evaluation->stack);
  free(evaluation);
}
