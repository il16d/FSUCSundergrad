#include <gmp.h>
#include <unistd.h>
#include <stdio.h>


#include "activation.h"
#include "evaluation.h"
#include "returns.h"
#include "assign.h"

// so that fail can call these
activation a;
evaluation e;
returns r;


int main()
{

a = activation_create("Activation stack",1000);
e = evaluation_create("Evaluation stack",1000);
r = returns_create("Returns stack",1000);

// 
// 


// x = integer.sqrt(integer.add(integer.multiply(3,integer.add(1,2)),integer.multiply(integer.add(3,1),4)))

/*
a->allocate(a,1); // space for x

e->allocate_out(e,1); // integer.sqrt
e->allocate_out(e,1); // outer integer.add()
e->allocate_out(e,1); // integer.multiply
e->allocate_constant(e,"3"); 
e->allocate_out(e,1); // integer.add
e->allocate_constant(e,"1");
e->allocate_constant(e,"2");

r->push(r,&&l0);
goto integer_add;
l0: e->deallocate(e,2,1);

r->push(r,&&l1);
goto integer_multiply;
l1: e->deallocate(e,2,1);

e->allocate_out(e,1); // integer.multiply
e->allocate_out(e,1); // integer.add
e->allocate_constant(e,"3"); // integer.add
e->allocate_constant(e,"1"); // integer.add

variable_enumerate();

r->push(r,&&l2);
goto integer_add;
l2: e->deallocate(e,2,1);

e->allocate_constant(e,"4"); // integer.multiply

r->push(r,&&l3);
goto integer_multiply;
l3: e->deallocate(e,2,1);

r->push(r,&&l4);
goto integer_add;
l4: e->deallocate(e,2,1);

r->push(r,&&l5);
goto integer_sqrt;
l5:

e->deallocate(e,1,1);      // deallocate the in variable for sqrt

assign(a,e,1,1);    // take the top value left on the stack and 
e->deallocate(e,1,1);   // deallocate the out variable for sqrt

// now do some i/o
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,1,NEW_PTR); 
e->allocate_constant(e,"1");

r->push(r,&&l6);
goto linux_write;

l6:

// cleanup from write
e->deallocate(e,1,1);
e->deallocate(e,1,1);
e->deallocate(e,1,1);

e->deallocate(e,1,1);     // throwaway the return value
a->deallocate(a,1);

e->print(e);
a->print(a);

variable_enumerate();
exit(0);
*/




mpz_t _integer_tmp0;
mpz_t _integer_tmp1;
mpz_t _integer_tmp2;
mpz_t _integer_tmp3;
mpz_t _integer_tmp4;
mpz_t _integer_tmp5;
mpz_t _integer_tmp6;
mpz_t _integer_tmp7;
mpz_t _integer_tmp8;
mpz_t _integer_tmp9;

int _integer_tmpint0;
int _integer_tmpint1;
int _integer_tmpint2;

char *_integer_tmpstr0;
char *_integer_tmpstr1;
char *_integer_tmpstr2;

integer_add:

mpz_init(_integer_tmp0);
mpz_init(_integer_tmp1);
mpz_init(_integer_tmp2);

mpz_set_str(_integer_tmp0,e->deref(e,1),10);
mpz_set_str(_integer_tmp1,e->deref(e,2),10);
mpz_add(_integer_tmp2,_integer_tmp0,_integer_tmp1);

_integer_tmpint0 = mpz_sizeinbase(_integer_tmp2,10) + 2;
_integer_tmpstr0 = malloc(_integer_tmpint0);
gmp_snprintf(_integer_tmpstr0,_integer_tmpint0,"%Zd",_integer_tmp2);

e->stack[e->top - 3]->destroy(e->stack[e->top - 3]);
e->stack[e->top - 3] = variable_create("gmp variable",_integer_tmpstr0);

mpz_clear(_integer_tmp0);
mpz_clear(_integer_tmp1);
mpz_clear(_integer_tmp2);

goto *r->pop(r);


integer_multiply:

mpz_init(_integer_tmp0);
mpz_init(_integer_tmp1);
mpz_init(_integer_tmp2);

mpz_set_str(_integer_tmp0,e->deref(e,1),10);
mpz_set_str(_integer_tmp1,e->deref(e,2),10);
mpz_mul(_integer_tmp2,_integer_tmp0,_integer_tmp1);

_integer_tmpint0 = mpz_sizeinbase(_integer_tmp2,10) + 2;
_integer_tmpstr0 = malloc(_integer_tmpint0);
gmp_snprintf(_integer_tmpstr0,_integer_tmpint0,"%Zd",_integer_tmp2);

e->stack[e->top - 3]->destroy(e->stack[e->top - 3]);
e->stack[e->top - 3] = variable_create("gmp variable",_integer_tmpstr0);

mpz_clear(_integer_tmp0);
mpz_clear(_integer_tmp1);
mpz_clear(_integer_tmp2);

goto *r->pop(r);



integer_divide:

mpz_init(_integer_tmp0);
mpz_init(_integer_tmp1);
mpz_init(_integer_tmp2);
mpz_init(_integer_tmp3);

mpz_set_str(_integer_tmp0,e->deref(e,1),10);
mpz_set_str(_integer_tmp1,e->deref(e,2),10);
mpz_fdiv_qr(_integer_tmp2,_integer_tmp3,_integer_tmp1,_integer_tmp0);

_integer_tmpint0 = mpz_sizeinbase(_integer_tmp2,10) + 2;
_integer_tmpstr0 = malloc(_integer_tmpint0);
gmp_snprintf(_integer_tmpstr0,_integer_tmpint0,"%Zd",_integer_tmp2);

e->stack[e->top - 4]->destroy(e->stack[e->top - 4]);
e->stack[e->top - 4] = variable_create("gmp variable",_integer_tmpstr0);


_integer_tmpint0 = mpz_sizeinbase(_integer_tmp3,10) + 2;
_integer_tmpstr0 = malloc(_integer_tmpint0);
gmp_snprintf(_integer_tmpstr0,_integer_tmpint0,"%Zd",_integer_tmp3);

e->stack[e->top - 3]->destroy(e->stack[e->top - 3]);
e->stack[e->top - 3] = variable_create("gmp variable",_integer_tmpstr0);

mpz_clear(_integer_tmp0);
mpz_clear(_integer_tmp1);
mpz_clear(_integer_tmp2);
mpz_clear(_integer_tmp3);

goto *r->pop(r);



integer_sqrt:

mpz_init(_integer_tmp0);
mpz_init(_integer_tmp1);

mpz_set_str(_integer_tmp0,e->deref(e,1),10);
mpz_sqrt(_integer_tmp1,_integer_tmp0);

_integer_tmpint0 = mpz_sizeinbase(_integer_tmp1,10) + 2;
_integer_tmpstr0 = malloc(_integer_tmpint0);
gmp_snprintf(_integer_tmpstr0,_integer_tmpint0,"%Zd",_integer_tmp1);

e->stack[e->top - 2]->destroy(e->stack[e->top - 2]);
e->stack[e->top - 2] = variable_create("gmp variable",_integer_tmpstr0);

mpz_clear(_integer_tmp0);
mpz_clear(_integer_tmp1);

goto *r->pop(r);



int _linux_tmpint0 = 0;
int _linux_tmpint1;
int _linux_tmpint2;
int _linux_tmpint3;
int _linux_tmpint4;
int _linux_tmpint5;
int _linux_tmpint6;
int _linux_tmpint7;
int _linux_tmpint8;
int _linux_tmpint9;

char *_linux_tmpstr0;
char *_linux_tmpstr1;
char *_linux_tmpstr2;
char *_linux_tmpstr3;
char *_linux_tmpstr4;
char *_linux_tmpstr5;
char *_linux_tmpstr6;
char *_linux_tmpstr7;
char *_linux_tmpstr8;
char *_linux_tmpstr9;


linux_write:

_linux_tmpint0 = atoi(e->deref(e,3));
_linux_tmpint1 = atoi(e->deref(e,1));
_linux_tmpint2 = write(_linux_tmpint0,e->deref(e,2),_linux_tmpint1);

_linux_tmpstr0 = (char *)malloc(_linux_tmpint1 + 2);
snprintf(_linux_tmpstr0,_linux_tmpint1+1,"%d",_linux_tmpint2);

e->stack[e->top - 4]->destroy(e->stack[e->top - 4]); // wasteful? Why bother having anything there?
e->stack[e->top - 4] = variable_create("linux variable",_linux_tmpstr0);
free(_linux_tmpstr0);

goto *r->pop(r);


}






