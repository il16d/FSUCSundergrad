



#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "returns.h"
#include "utility.h"

//declarations
static void returns_push(struct returns *returns, void *ptr);
static void *returns_pop(struct returns *returns);

static void returns_print(struct returns *returns);
static void returns_destroy(struct returns *returns);


// implementations
returns returns_create(char *name, int max)
{
  returns ret;

  ret = malloc(sizeof(struct returns));

  if(ret == NULL)
    {
      fail("returns_create: malloc() failed");
    }

  ret->name = strdup(name);
  ret->max_size = max;
  ret->top = 0;
  ret->stack = calloc(sizeof(struct variable),(size_t)max);

  if(ret->stack == NULL)
    {
      fail("returns_create: calloc() failed");
    }

  ret->push = &returns_push;
  ret->pop = &returns_pop;
  ret->print = &returns_print;
  ret->destroy = &returns_destroy;

  return(ret);
}

static void returns_push(struct returns *returns, void *ptr)
{
  if(returns->top < returns->max_size)
    {
      returns->stack[returns->top] = ptr;
      returns->top++;
    }
  else
    {
      fail("returns stack overflow!");
    }
}

static void *returns_pop(struct returns *returns)
{
  if(returns->top)
    {
      void *ptr = returns->stack[returns->top-1];
      returns->top--;
      return(ptr);
    }
  else
    {
      fail("return stack underflow");
    }
}

static void returns_print(struct returns *returns)
{
  int i;
  printf("Stack '%s'\n",returns->name);
  printf("  Maximum elements = %d\n",returns->max_size);
  printf("  Current elements = %d\n",returns->top);
  printf("  =====\n");
  for(i=0; i<returns->top; i++)
    {
      void *ptr = returns->stack[i];
      printf("  element %d: %p\n",i,ptr);
    }
  printf("  =====\n");
}

static void returns_destroy(struct returns *returns)
{
  free(returns->name);
  free(returns->stack);
  free(returns);
}
