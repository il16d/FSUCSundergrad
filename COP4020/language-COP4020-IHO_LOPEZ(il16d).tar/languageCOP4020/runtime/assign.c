
#include <stdlib.h>

#include "variable.h"
#include "activation.h"
#include "evaluation.h"
#include "returns.h"
#include "assign.h"

void assign(activation a, evaluation e, int where, int flag)
{
  if(where > a->top)
    fail("assignment attempt underflows activation stack");

  // get rid of the old value
  variable old_v;
  old_v = a->stack[a->top-where];
  if(old_v)
    old_v->destroy(old_v);

  // now copy over the new state
  if(flag == 0)
    {
      a->stack[a->top-where] = e->stack[e->top-1];
    }
  else
    {
      variable source = e->stack[e->top-1];
      a->stack[a->top-where] = source->copy(source);
    }
}

void copy_to_evaluation(evaluation e, activation a, int where, int flag)
{
  if(where > a->top)
    fail("assignment attempt underflows activation stack");

  if(flag == 0)
    {
      // just move the variable itself
      variable source = a->stack[a->top-where];
      e->push(e,source);
    }
  else
    {
      // make a fresh copy
      variable source = a->stack[a->top - where];
      variable source_copy = source->copy(source);
      e->push(e,source_copy);
    }
}
