
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


#include <Judy.h>  // looking for memory leak
static Pvoid_t ptr_check = (Pvoid_t) NULL;

#include "variable.h"
#include "../both/pleasant.h"

static variable variable_copy(variable source);
static void variable_print(variable v);
static void variable_destroy(variable v);
static void variable_modify(variable v, char *newvalue);

variable variable_create(char *name, char *value)
{
  variable ret = malloc(sizeof(struct variable));
  if(ret == NULL)
    fail("variable_create: malloc() failed");
  //  printf("Create: variable %p \n",ret);

  if(name)
    {
      ret->name = strdup(name);
    }
  else
    {
      ret->name = NULL;
    }

  if(value)
    {
      ret->value = strdup(value);
      ret->count = strlen(value)+1;
    }
  else
    {
      ret->value = NULL;
      ret->count = 0;
    }

  ret->copy = &variable_copy;
  ret->print = &variable_print;
  ret->destroy = &variable_destroy;
  ret->modify = &variable_modify;

  /*
  int ptr_length = snprintf(0,0,"%p",ret);
  char *ptrstring = malloc(ptr_length+1);
  snprintf(ptrstring,ptr_length,"%p",ret);
  */

  /*
  Word_t *PValue;
  JSLI(PValue,ptr_check,(uint8_t *)ptrstring);
  *PValue = (unsigned long)ptrstring;
  */

  /*
  int judy_return;
  J1S(judy_return,ptr_check,(Word_t)ret);
  if(judy_return == JERR)
    fail("variable_create: judy insert fails");
  if(judy_return == 0)
    fail("variable create: judy asserts duplicate variable pointer created?!");
  */

  return(ret);
}

static variable variable_copy(variable source)
{
  variable dest = variable_create("copy",source->value);
  return(dest);
}

static void variable_print(variable v)
{
  printf("%s = '%s' (count = %ld, ptr = %p)",v->name,v->value,v->count,v);
}

static void variable_destroy(variable v)
{
  //  printf("Destroy: variable %p \n",v);

  /*
  Word_t *PValue;
  int ptr_length = snprintf(0,0,"%p",v);
  char *ptrstring = malloc(ptr_length+1);
  snprintf(ptrstring,ptr_length,"%p",v);
  JSLG(PValue,ptr_check,(uint8_t *)index);
  */
  /*
  if(judy_return == JERR)
    fail("variable_destroy: judy library reports error");
  */
  /*
  if(PValue == 0)
    {
      printf("Failing!\n");
      variable_enumerate();
      fail("variable_destroy: judy reports destruction of variable that's not set in judy?!");
    }
  */
  
  free(v->name);
  free(v->value);
  free(v);
}

static void variable_modify(variable v, char *newvalue)
{
  free(v->value);
  if(newvalue)
    {
      v->value = strdup(newvalue);
      v->count = strlen(newvalue)+1;
    }
  else
    {
      v->value = NULL;
      v->count = 0;
    }
}

void variable_enumerate()
{
  return;
  printf("Active variables:\n");
  printf("=================\n");
  
  int judy_return;
  Word_t index = 0;
  J1F(judy_return,ptr_check,index);
  if(judy_return == 0)
    {
      printf("\t [ EMPTY ]\n");
    }
  else
    {
      /*
      printf("\t %p == ",(void *)index);
      variable v = (variable)index;
      v->print(v);
      printf("\n");
      */

      while(judy_return == 1)
	{
	  printf("\t %p == ",(void *)index);
	  variable v = (variable)index;
	  v->print(v);
	  printf("\n");
	  J1N(judy_return,ptr_check,index);
	}
    }

}
