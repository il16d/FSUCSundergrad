
_exit:

// debug
e->print(e);
a->print(a);
r->print(r);

variable_enumerate();

e->destroy(e);
a->destroy(a);
r->destroy(r);
exit(0);


/* Integer functions, courtesy of GMP */


mpz_t _integer_tmp0;
mpz_t _integer_tmp1;
mpz_t _integer_tmp2;
mpz_t _integer_tmp3;
mpz_t _integer_tmp4;
mpz_t _integer_tmp5;
mpz_t _integer_tmp6;
mpz_t _integer_tmp7;
mpz_t _integer_tmp8;
mpz_t _integer_tmp9;

int _integer_tmpint0;
int _integer_tmpint1;
int _integer_tmpint2;

char *_integer_tmpstr0;
char *_integer_tmpstr1;
char *_integer_tmpstr2;


/* Addition */

integer_add:

mpz_init(_integer_tmp0);
mpz_init(_integer_tmp1);
mpz_init(_integer_tmp2);

mpz_set_str(_integer_tmp0,e->deref(e,1),10);
mpz_set_str(_integer_tmp1,e->deref(e,2),10);
mpz_add(_integer_tmp2,_integer_tmp0,_integer_tmp1);

_integer_tmpint0 = mpz_sizeinbase(_integer_tmp2,10) + 2;
_integer_tmpstr0 = malloc(_integer_tmpint0);
gmp_snprintf(_integer_tmpstr0,_integer_tmpint0,"%Zd",_integer_tmp2);

e->stack[e->top - 3]->destroy(e->stack[e->top - 3]);
e->stack[e->top - 3] = variable_create("gmp variable",_integer_tmpstr0);

mpz_clear(_integer_tmp0);
mpz_clear(_integer_tmp1);
mpz_clear(_integer_tmp2);

free(_integer_tmpstr0);

goto *r->pop(r);


/* Subtraction */

integer_subtract:

mpz_init(_integer_tmp0);
mpz_init(_integer_tmp1);
mpz_init(_integer_tmp2);

mpz_set_str(_integer_tmp0,e->deref(e,1),10);
mpz_set_str(_integer_tmp1,e->deref(e,2),10);
mpz_sub(_integer_tmp2,_integer_tmp1,_integer_tmp0);

_integer_tmpint0 = mpz_sizeinbase(_integer_tmp2,10) + 2;
_integer_tmpstr0 = malloc(_integer_tmpint0);
gmp_snprintf(_integer_tmpstr0,_integer_tmpint0,"%Zd",_integer_tmp2);

e->stack[e->top - 3]->destroy(e->stack[e->top - 3]);
e->stack[e->top - 3] = variable_create("gmp variable",_integer_tmpstr0);

mpz_clear(_integer_tmp0);
mpz_clear(_integer_tmp1);
mpz_clear(_integer_tmp2);

free(_integer_tmpstr0);

goto *r->pop(r);


/* Multiplication */

integer_multiply:

mpz_init(_integer_tmp0);
mpz_init(_integer_tmp1);
mpz_init(_integer_tmp2);

mpz_set_str(_integer_tmp0,e->deref(e,1),10);
mpz_set_str(_integer_tmp1,e->deref(e,2),10);
mpz_mul(_integer_tmp2,_integer_tmp0,_integer_tmp1);

_integer_tmpint0 = mpz_sizeinbase(_integer_tmp2,10) + 2;
_integer_tmpstr0 = malloc(_integer_tmpint0);
gmp_snprintf(_integer_tmpstr0,_integer_tmpint0,"%Zd",_integer_tmp2);

e->stack[e->top - 3]->destroy(e->stack[e->top - 3]);
e->stack[e->top - 3] = variable_create("gmp variable",_integer_tmpstr0);

mpz_clear(_integer_tmp0);
mpz_clear(_integer_tmp1);
mpz_clear(_integer_tmp2);

free(_integer_tmpstr0);

goto *r->pop(r);


/* Division */

integer_divide:

mpz_init(_integer_tmp0);
mpz_init(_integer_tmp1);
mpz_init(_integer_tmp2);
mpz_init(_integer_tmp3);

mpz_set_str(_integer_tmp0,e->deref(e,1),10);
mpz_set_str(_integer_tmp1,e->deref(e,2),10);
mpz_fdiv_qr(_integer_tmp2,_integer_tmp3,_integer_tmp1,_integer_tmp0);

_integer_tmpint0 = mpz_sizeinbase(_integer_tmp2,10) + 2;
_integer_tmpstr0 = malloc(_integer_tmpint0);
gmp_snprintf(_integer_tmpstr0,_integer_tmpint0,"%Zd",_integer_tmp2);

e->stack[e->top - 4]->destroy(e->stack[e->top - 4]);
e->stack[e->top - 4] = variable_create("gmp variable",_integer_tmpstr0);

free(_integer_tmpstr0);

_integer_tmpint0 = mpz_sizeinbase(_integer_tmp3,10) + 2;
_integer_tmpstr0 = malloc(_integer_tmpint0);
gmp_snprintf(_integer_tmpstr0,_integer_tmpint0,"%Zd",_integer_tmp3);

e->stack[e->top - 3]->destroy(e->stack[e->top - 3]);
e->stack[e->top - 3] = variable_create("gmp variable",_integer_tmpstr0);

mpz_clear(_integer_tmp0);
mpz_clear(_integer_tmp1);
mpz_clear(_integer_tmp2);
mpz_clear(_integer_tmp3);

free(_integer_tmpstr0);

goto *r->pop(r);


/* Square root */

integer_sqrt:

mpz_init(_integer_tmp0);
mpz_init(_integer_tmp1);

mpz_set_str(_integer_tmp0,e->deref(e,1),10);
mpz_sqrt(_integer_tmp1,_integer_tmp0);

_integer_tmpint0 = mpz_sizeinbase(_integer_tmp1,10) + 2;
_integer_tmpstr0 = malloc(_integer_tmpint0);
gmp_snprintf(_integer_tmpstr0,_integer_tmpint0,"%Zd",_integer_tmp1);

e->stack[e->top - 2]->destroy(e->stack[e->top - 2]);
e->stack[e->top - 2] = variable_create("gmp variable",_integer_tmpstr0);

mpz_clear(_integer_tmp0);
mpz_clear(_integer_tmp1);

free(_integer_tmpstr0);

goto *r->pop(r);


/* Equality */

integer_equal:

mpz_init(_integer_tmp0);
mpz_init(_integer_tmp1);

mpz_set_str(_integer_tmp0,e->deref(e,1),10);
mpz_set_str(_integer_tmp1,e->deref(e,2),10);
_integer_tmpint0 = mpz_cmp(_integer_tmp0,_integer_tmp1);

e->stack[e->top - 3]->destroy(e->stack[e->top - 3]);
if(_integer_tmpint0 == 0)
  e->stack[e->top - 3] = variable_create("gmp variable","true");
else
  e->stack[e->top - 3] = variable_create("gmp variable","false");

mpz_clear(_integer_tmp0);
mpz_clear(_integer_tmp1);

goto *r->pop(r);



/* Linux system calls */

int _linux_tmpint0 = 0;
int _linux_tmpint1;
int _linux_tmpint2;
int _linux_tmpint3;
int _linux_tmpint4;
int _linux_tmpint5;
int _linux_tmpint6;
int _linux_tmpint7;
int _linux_tmpint8;
int _linux_tmpint9;

char *_linux_tmpstr0;
char *_linux_tmpstr1;
char *_linux_tmpstr2;
char *_linux_tmpstr3;
char *_linux_tmpstr4;
char *_linux_tmpstr5;
char *_linux_tmpstr6;
char *_linux_tmpstr7;
char *_linux_tmpstr8;
char *_linux_tmpstr9;


/* write() */

linux_write:

_linux_tmpint0 = atoi(e->deref(e,3));
_linux_tmpint1 = atoi(e->deref(e,1));
_linux_tmpint2 = write(_linux_tmpint0,e->deref(e,2),_linux_tmpint1);

_linux_tmpstr0 = (char *)malloc(_linux_tmpint1 + 2);
snprintf(_linux_tmpstr0,_linux_tmpint1+1,"%d",_linux_tmpint2);

e->stack[e->top - 4]->destroy(e->stack[e->top - 4]); // wasteful? Why bother having anything there?
e->stack[e->top - 4] = variable_create("linux variable",_linux_tmpstr0);

free(_linux_tmpstr0);

goto *r->pop(r);


/* (bytesreceived,buffer) = read(filedescriptor,bytesrequested) */

linux_read:

_linux_tmpint0 = atoi(e->deref(e,2)); // file descriptor
_linux_tmpint1 = atoi(e->deref(e,1)); // buffer size

_linux_tmpstr0 = (char *)malloc(_linux_tmpint1); // output buffer

_linux_tmpint2 = read(_linux_tmpint0,_linux_tmpstr0,_linux_tmpint1); // bytes read

_linux_tmpint3 = snprintf(0,0,"%+d",_linux_tmpint2); // Courtesy of stack overflow's discussion 
_linux_tmpstr1 = (char *)malloc(_linux_tmpint3+1);
snprintf(_linux_tmpstr1,_linux_tmpint3,"%d",_linux_tmpint2); 

e->stack[e->top - 4]->destroy(e->stack[e->top - 4]); // write out size in bytes
e->stack[e->top - 4] = variable_create("linux variable num of bytes",_linux_tmpstr1);
e->stack[e->top - 3]->destroy(e->stack[e->top - 3]); // write out buffer -- what if it contains a zero byte, though!?
e->stack[e->top - 3] = variable_create("linux variable buffer",_linux_tmpstr0);

free(_linux_tmpstr0);
free(_linux_tmpstr1);

goto *r->pop(r);


/* exit() */

linux_exit:

// a bit of debug

_linux_tmpint0 = atoi(e->deref(e,1));

e->print(e);
a->print(a);
r->print(r);

variable_enumerate();

exit(_linux_tmpint0);


/* String functions */


int _string_tmpint0;
int _string_tmpint1;
int _string_tmpint2;
int _string_tmpint3;
int _string_tmpint4;
int _string_tmpint5;
int _string_tmpint6;
int _string_tmpint7;
int _string_tmpint8;
int _string_tmpint9;


char *_string_tmpstr0;
char *_string_tmpstr1;
char *_string_tmpstr2;
char *_string_tmpstr3;
char *_string_tmpstr4;
char *_string_tmpstr5;
char *_string_tmpstr6;
char *_string_tmpstr7;
char *_string_tmpstr8;
char *_string_tmpstr9;


/* (count) = length(string) */

string_length:

//printf("setting up string length:\n");
//e->print(e);

_string_tmpint0 = e->stack[e->top-1]->count-1;
//printf("This string '%s' has %d characters\n",e->stack[e->top-1]->value,_string_tmpint0);

_string_tmpstr0 = (char *)malloc(_string_tmpint0 + 1); // no negative numbers possible
snprintf(_string_tmpstr0,_string_tmpint0+1,"%d",_string_tmpint0);
//printf("Now, this string '%s' has '%s' characters\n",e->stack[e->top-1]->value,_string_tmpstr0);

e->stack[e->top - 2]->destroy(e->stack[e->top - 2]);
e->stack[e->top - 2] = variable_create("string length() variable",_string_tmpstr0);

free(_string_tmpstr0);

goto *r->pop(r);


}






