
#ifndef ASSIGN
#define ASSIGN

#define SAME_PTR      0
#define NEW_PTR       1

// moves from the top of evaluation stack to the activation stack
void assign(activation, evaluation, int, int);
// moves from the activation stack to the top of the evaluation stack
void copy_to_evaluation(evaluation e, activation a, int where, int flag);

#endif
