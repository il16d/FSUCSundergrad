
#ifndef VARIABLE
#define VARIABLE

struct variable
{
  char *name;
  char *value;
  size_t count;

  struct variable *(*copy)(struct variable *);
  void (*print)(struct variable *);
  void (*destroy)(struct variable *);
  void (*modify)(struct variable *, char *);
};

typedef struct variable *variable;

variable variable_create(char *, char *);
void variable_enumerate();

#endif


