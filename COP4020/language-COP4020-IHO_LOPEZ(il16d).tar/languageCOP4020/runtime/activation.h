// run-time structure

#include <stdlib.h>
#include "variable.h"
#include "../both/pleasant.h"

#ifndef ACTIVATION
#define ACTIVATION

struct activation
{
  char *name;
  int max_size;
  int top;
  variable *stack;

  void (*push)(struct activation *, variable); 
  void (*pop)(struct activation *);        // go ahead and destroy

  void (*allocate)(struct activation *, int count);
  void (*deallocate)(struct activation *, int count);

  void (*print)(struct activation *);
  void (*destroy)(struct activation *);
};

typedef struct activation *activation;

activation activation_create(char *name, int max);

void assign_from_evaluation(struct activation *activation, int from, int to);
void assign_from_activation(struct activation *activation, int from, int to);

#endif
