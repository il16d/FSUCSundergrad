#include <gmp.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>


#include "activation.h"
#include "evaluation.h"
#include "returns.h"
#include "assign.h"

// so that fail can call these
activation a;
evaluation e;
returns r;


int main()
{

a = activation_create("Activation stack",1000);
e = evaluation_create("Evaluation stack",1000);
r = returns_create("Returns stack",1000);

char *_p;   // used to see if the top of the evaluation stack evaluates to false

goto _main;
