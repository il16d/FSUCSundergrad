
/*

  Utility functions



 */

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include "utility.h"


void fail(const char *description, ...)
{
  va_list ap;
  va_start(ap,description);
  vfprintf(stderr,(const char *)description,ap);
  exit(1);
}
