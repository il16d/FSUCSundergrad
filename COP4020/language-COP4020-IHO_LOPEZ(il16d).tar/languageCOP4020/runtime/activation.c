
#include <string.h>
#include <stdio.h>

#include "activation.h"


//declarations
static void activation_push(struct activation *activation, variable v);
static void activation_pop(struct activation *activation);

static void activation_allocate(struct activation *, int count);
static void activation_deallocate(struct activation *, int count);

static void activation_print(struct activation *activation);
static void activation_destroy(struct activation *activation);


// implementations
activation activation_create(char *name, int max)
{
  activation ret;

  ret = malloc(sizeof(struct activation));

  if(ret == NULL)
    {
      fail("activation_create: malloc() failed");
    }

  ret->name = strdup(name);
  ret->max_size = max;
  ret->top = 0;
  ret->stack = calloc(sizeof(struct variable),(size_t)max);

  if(ret->stack == NULL)
    {
      fail("activation_create: calloc() failed");
    }

  ret->push = &activation_push;
  ret->pop = &activation_pop;
  ret->allocate = &activation_allocate;
  ret->deallocate = &activation_deallocate;
  ret->print = &activation_print;
  ret->destroy = &activation_destroy;

  return(ret);
}

static void activation_push(struct activation *activation, variable v)
{
  if(activation->top < activation->max_size)
    {
      activation->stack[activation->top] = v;
      activation->top++;
    }
  else
    {
      fail("activation stack overflow!");
    }
}

static void activation_pop(struct activation *activation)
{
  if(activation->top)
    {
      variable v = activation->stack[activation->top-1];
      activation->top--;
      v->destroy(v);
    }
}

static void activation_allocate(struct activation *a, int count)
{
  int i;
  for(i=0;i<count;i++)
    {
      variable v = variable_create("automatic allocation","");
      a->push(a,v);
    }
}

static void activation_deallocate(struct activation *a, int count)
{
  int i;
  for(i=0;i<count;i++)
    {
      a->pop(a);
    }
}

static void activation_print(struct activation *activation)
{
  int i;
  printf("Stack '%s'\n",activation->name);
  printf("  Maximum elements = %d\n",activation->max_size);
  printf("  Current elements = %d\n",activation->top);
  printf("  =====\n");
  for(i=0; i<activation->top; i++)
    {
      printf("  element %d: ",i);
      variable v = activation->stack[i];
      v->print(v);
      printf("\n");
    }
  printf("  =====\n");
}


static void activation_destroy(struct activation *activation)
{
  free(activation->name);
  free(activation->stack);
  free(activation);
}

