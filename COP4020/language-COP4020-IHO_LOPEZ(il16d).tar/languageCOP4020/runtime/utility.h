
// external

#ifndef UTILITY

#define UTILITY

void fail(const char *description, ...)
  __attribute__ ((noreturn));

#endif
