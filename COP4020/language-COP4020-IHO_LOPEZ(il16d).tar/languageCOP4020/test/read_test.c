_main:
e->allocate_constant(e,"0");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,"");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,"1");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
_l000000:
e->allocate_out(e,1);
copy_to_evaluation(e,a,1,1);
e->allocate_constant(e,"1");
r->push(r,&&_l000002);
goto integer_equal;
_l000002:
e->deallocate(e,2,1);
_p = e->deref(e,1);
if((strcmp(_p,"0")==0)||(strcmp(_p,"false")==0)) goto _l000001;
e->deallocate(e,1,1);
e->allocate_out(e,2);
e->allocate_constant(e,"0");
e->allocate_constant(e,"30");
r->push(r,&&_l000003);
goto linux_read;
_l000003:
e->deallocate(e,2,1);
assign(a,e,2,1);
e->deallocate(e,1,1);
assign(a,e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,2,1);
copy_to_evaluation(e,a,3,1);
r->push(r,&&_l000004);
goto linux_write;
_l000004:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,3,1);
e->allocate_constant(e,"0");
r->push(r,&&_l000007);
goto integer_equal;
_l000007:
e->deallocate(e,2,1);
_p = e->deref(e,1);
if((strcmp(_p,"0")==0)||(strcmp(_p,"false")==0)) goto _l000005;
e->deallocate(e,1,1);
e->allocate_constant(e,"0");
assign(a,e,1,1);
e->deallocate(e,1,1);
goto _l000006;
_l000005:
e->deallocate(e,1,1);
_l000006:
goto _l000000;
_l000001:
e->deallocate(e,1,1);
a->deallocate(a,3);
goto _exit;
