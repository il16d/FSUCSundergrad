_main:
e->allocate_out(e,1);
e->allocate_constant(e,"6");
r->push(r,&&_l000000);
goto main_factorial;
_l000000:
e->deallocate(e,1,1);
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,"factorial(6) = ");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,1,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,1,1);
r->push(r,&&_l000001);
goto string_length;
_l000001:
e->deallocate(e,1,1);
r->push(r,&&_l000002);
goto linux_write;
_l000002:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,2,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,2,1);
r->push(r,&&_l000003);
goto string_length;
_l000003:
e->deallocate(e,1,1);
r->push(r,&&_l000004);
goto linux_write;
_l000004:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
e->allocate_constant(e,"\n");
e->allocate_constant(e,"1");
r->push(r,&&_l000005);
goto linux_write;
_l000005:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
a->deallocate(a,2);
goto _exit;
main_factorial:   // function main_factorial begins here
e->allocate_out(e,1);
e->dup(e,2,1);
e->allocate_constant(e,"1");
r->push(r,&&_l000008);
goto integer_equal;
_l000008:
e->deallocate(e,2,1);
_p = e->deref(e,1);
if((strcmp(_p,"0")==0)||(strcmp(_p,"false")==0)) goto _l000006;
e->deallocate(e,1,1);
e->allocate_constant(e,"1");
e->copy_e_e(e,3,1,1);
e->deallocate(e,1,1);
goto _l000007;
_l000006:
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->dup(e,2,1);
e->allocate_constant(e,"1");
r->push(r,&&_l000009);
goto integer_subtract;
_l000009:
e->deallocate(e,2,1);
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->dup(e,2,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,1,1);
r->push(r,&&_l000010);
goto main_factorial;
_l000010:
e->deallocate(e,1,1);
r->push(r,&&_l000011);
goto integer_multiply;
_l000011:
e->deallocate(e,2,1);
e->copy_e_e(e,3,1,1);
e->deallocate(e,1,1);
a->deallocate(a,1);
_l000007:
goto *r->pop(r); // function main_factorial ends here
