_main:
e->allocate_out(e,1);
e->allocate_constant(e,"1");
e->allocate_constant(e,"1");
r->push(r,&&_l000002);
goto integer_equal;
_l000002:
e->deallocate(e,2,1);
_p = e->deref(e,1);
if((strcmp(_p,"0")==0)||(strcmp(_p,"false")==0)) goto _l000000;
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
e->allocate_constant(e,"Passed\n");
e->allocate_constant(e,"7");
r->push(r,&&_l000003);
goto linux_write;
_l000003:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
goto _l000001;
_l000000:
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
e->allocate_constant(e,"Failed\n");
e->allocate_constant(e,"7");
r->push(r,&&_l000004);
goto linux_write;
_l000004:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
_l000001:
e->allocate_out(e,1);
e->allocate_constant(e,"1");
e->allocate_constant(e,"0");
r->push(r,&&_l000007);
goto integer_equal;
_l000007:
e->deallocate(e,2,1);
_p = e->deref(e,1);
if((strcmp(_p,"0")==0)||(strcmp(_p,"false")==0)) goto _l000005;
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
e->allocate_constant(e,"Failed\n");
e->allocate_constant(e,"7");
r->push(r,&&_l000008);
goto linux_write;
_l000008:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
goto _l000006;
_l000005:
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
e->allocate_constant(e,"Passed\n");
e->allocate_constant(e,"7");
r->push(r,&&_l000009);
goto linux_write;
_l000009:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
_l000006:
e->allocate_out(e,1);
e->allocate_constant(e,"77");
e->allocate_constant(e,"-76");
r->push(r,&&_l000012);
goto integer_equal;
_l000012:
e->deallocate(e,2,1);
_p = e->deref(e,1);
if((strcmp(_p,"0")==0)||(strcmp(_p,"false")==0)) goto _l000010;
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
e->allocate_constant(e,"Failed\n");
e->allocate_constant(e,"7");
r->push(r,&&_l000013);
goto linux_write;
_l000013:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
goto _l000011;
_l000010:
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
e->allocate_constant(e,"Passed\n");
e->allocate_constant(e,"7");
r->push(r,&&_l000014);
goto linux_write;
_l000014:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
_l000011:
goto _exit;
