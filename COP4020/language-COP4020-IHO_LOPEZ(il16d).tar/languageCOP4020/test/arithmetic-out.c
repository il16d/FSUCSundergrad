#include <gmp.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>


#include "activation.h"
#include "evaluation.h"
#include "returns.h"
#include "assign.h"

// so that fail can call these
activation a;
evaluation e;
returns r;


int main()
{

a = activation_create("Activation stack",1000);
e = evaluation_create("Evaluation stack",1000);
r = returns_create("Returns stack",1000);

char *_p;   // used to see if the top of the evaluation stack evaluates to false

goto _main;
_main:
e->allocate_constant(e,"1");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,"2");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,"12");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,3,1);
copy_to_evaluation(e,a,2,1);
r->push(r,&&_l000000);
goto integer_add;
_l000000:
e->deallocate(e,2,1);
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,4,1);
copy_to_evaluation(e,a,2,1);
r->push(r,&&_l000001);
goto integer_multiply;
_l000001:
e->deallocate(e,2,1);
copy_to_evaluation(e,a,2,1);
r->push(r,&&_l000002);
goto integer_multiply;
_l000002:
e->deallocate(e,2,1);
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,"0");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,2,1);
r->push(r,&&_l000003);
goto integer_sqrt;
_l000003:
e->deallocate(e,1,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,"x = ");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,", y = ");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,", z = ");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,", a = ");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,", b = ");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,", k = ");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,"\n");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,7,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,7,1);
r->push(r,&&_l000004);
goto string_length;
_l000004:
e->deallocate(e,1,1);
r->push(r,&&_l000005);
goto linux_write;
_l000005:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,13,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,13,1);
r->push(r,&&_l000006);
goto string_length;
_l000006:
e->deallocate(e,1,1);
r->push(r,&&_l000007);
goto linux_write;
_l000007:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,6,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,6,1);
r->push(r,&&_l000008);
goto string_length;
_l000008:
e->deallocate(e,1,1);
r->push(r,&&_l000009);
goto linux_write;
_l000009:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,12,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,12,1);
r->push(r,&&_l000010);
goto string_length;
_l000010:
e->deallocate(e,1,1);
r->push(r,&&_l000011);
goto linux_write;
_l000011:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,5,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,5,1);
r->push(r,&&_l000012);
goto string_length;
_l000012:
e->deallocate(e,1,1);
r->push(r,&&_l000013);
goto linux_write;
_l000013:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,11,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,11,1);
r->push(r,&&_l000014);
goto string_length;
_l000014:
e->deallocate(e,1,1);
r->push(r,&&_l000015);
goto linux_write;
_l000015:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,4,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,4,1);
r->push(r,&&_l000016);
goto string_length;
_l000016:
e->deallocate(e,1,1);
r->push(r,&&_l000017);
goto linux_write;
_l000017:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,10,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,10,1);
r->push(r,&&_l000018);
goto string_length;
_l000018:
e->deallocate(e,1,1);
r->push(r,&&_l000019);
goto linux_write;
_l000019:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,3,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,3,1);
r->push(r,&&_l000020);
goto string_length;
_l000020:
e->deallocate(e,1,1);
r->push(r,&&_l000021);
goto linux_write;
_l000021:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,9,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,9,1);
r->push(r,&&_l000022);
goto string_length;
_l000022:
e->deallocate(e,1,1);
r->push(r,&&_l000023);
goto linux_write;
_l000023:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,2,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,2,1);
r->push(r,&&_l000024);
goto string_length;
_l000024:
e->deallocate(e,1,1);
r->push(r,&&_l000025);
goto linux_write;
_l000025:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,8,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,8,1);
r->push(r,&&_l000026);
goto string_length;
_l000026:
e->deallocate(e,1,1);
r->push(r,&&_l000027);
goto linux_write;
_l000027:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,1,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,1,1);
r->push(r,&&_l000028);
goto string_length;
_l000028:
e->deallocate(e,1,1);
r->push(r,&&_l000029);
goto linux_write;
_l000029:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
a->deallocate(a,13);
goto _exit;

_exit:

// debug
e->print(e);
a->print(a);
r->print(r);

variable_enumerate();

e->destroy(e);
a->destroy(a);
r->destroy(r);
exit(0);


/* Integer functions, courtesy of GMP */


mpz_t _integer_tmp0;
mpz_t _integer_tmp1;
mpz_t _integer_tmp2;
mpz_t _integer_tmp3;
mpz_t _integer_tmp4;
mpz_t _integer_tmp5;
mpz_t _integer_tmp6;
mpz_t _integer_tmp7;
mpz_t _integer_tmp8;
mpz_t _integer_tmp9;

int _integer_tmpint0;
int _integer_tmpint1;
int _integer_tmpint2;

char *_integer_tmpstr0;
char *_integer_tmpstr1;
char *_integer_tmpstr2;


/* Addition */

integer_add:

mpz_init(_integer_tmp0);
mpz_init(_integer_tmp1);
mpz_init(_integer_tmp2);

mpz_set_str(_integer_tmp0,e->deref(e,1),10);
mpz_set_str(_integer_tmp1,e->deref(e,2),10);
mpz_add(_integer_tmp2,_integer_tmp0,_integer_tmp1);

_integer_tmpint0 = mpz_sizeinbase(_integer_tmp2,10) + 2;
_integer_tmpstr0 = malloc(_integer_tmpint0);
gmp_snprintf(_integer_tmpstr0,_integer_tmpint0,"%Zd",_integer_tmp2);

e->stack[e->top - 3]->destroy(e->stack[e->top - 3]);
e->stack[e->top - 3] = variable_create("gmp variable",_integer_tmpstr0);

mpz_clear(_integer_tmp0);
mpz_clear(_integer_tmp1);
mpz_clear(_integer_tmp2);

free(_integer_tmpstr0);

goto *r->pop(r);


/* Subtraction */

integer_subtract:

mpz_init(_integer_tmp0);
mpz_init(_integer_tmp1);
mpz_init(_integer_tmp2);

mpz_set_str(_integer_tmp0,e->deref(e,1),10);
mpz_set_str(_integer_tmp1,e->deref(e,2),10);
mpz_sub(_integer_tmp2,_integer_tmp1,_integer_tmp0);

_integer_tmpint0 = mpz_sizeinbase(_integer_tmp2,10) + 2;
_integer_tmpstr0 = malloc(_integer_tmpint0);
gmp_snprintf(_integer_tmpstr0,_integer_tmpint0,"%Zd",_integer_tmp2);

e->stack[e->top - 3]->destroy(e->stack[e->top - 3]);
e->stack[e->top - 3] = variable_create("gmp variable",_integer_tmpstr0);

mpz_clear(_integer_tmp0);
mpz_clear(_integer_tmp1);
mpz_clear(_integer_tmp2);

free(_integer_tmpstr0);

goto *r->pop(r);


/* Multiplication */

integer_multiply:

mpz_init(_integer_tmp0);
mpz_init(_integer_tmp1);
mpz_init(_integer_tmp2);

mpz_set_str(_integer_tmp0,e->deref(e,1),10);
mpz_set_str(_integer_tmp1,e->deref(e,2),10);
mpz_mul(_integer_tmp2,_integer_tmp0,_integer_tmp1);

_integer_tmpint0 = mpz_sizeinbase(_integer_tmp2,10) + 2;
_integer_tmpstr0 = malloc(_integer_tmpint0);
gmp_snprintf(_integer_tmpstr0,_integer_tmpint0,"%Zd",_integer_tmp2);

e->stack[e->top - 3]->destroy(e->stack[e->top - 3]);
e->stack[e->top - 3] = variable_create("gmp variable",_integer_tmpstr0);

mpz_clear(_integer_tmp0);
mpz_clear(_integer_tmp1);
mpz_clear(_integer_tmp2);

free(_integer_tmpstr0);

goto *r->pop(r);


/* Division */

integer_divide:

mpz_init(_integer_tmp0);
mpz_init(_integer_tmp1);
mpz_init(_integer_tmp2);
mpz_init(_integer_tmp3);

mpz_set_str(_integer_tmp0,e->deref(e,1),10);
mpz_set_str(_integer_tmp1,e->deref(e,2),10);
mpz_fdiv_qr(_integer_tmp2,_integer_tmp3,_integer_tmp1,_integer_tmp0);

_integer_tmpint0 = mpz_sizeinbase(_integer_tmp2,10) + 2;
_integer_tmpstr0 = malloc(_integer_tmpint0);
gmp_snprintf(_integer_tmpstr0,_integer_tmpint0,"%Zd",_integer_tmp2);

e->stack[e->top - 4]->destroy(e->stack[e->top - 4]);
e->stack[e->top - 4] = variable_create("gmp variable",_integer_tmpstr0);

free(_integer_tmpstr0);

_integer_tmpint0 = mpz_sizeinbase(_integer_tmp3,10) + 2;
_integer_tmpstr0 = malloc(_integer_tmpint0);
gmp_snprintf(_integer_tmpstr0,_integer_tmpint0,"%Zd",_integer_tmp3);

e->stack[e->top - 3]->destroy(e->stack[e->top - 3]);
e->stack[e->top - 3] = variable_create("gmp variable",_integer_tmpstr0);

mpz_clear(_integer_tmp0);
mpz_clear(_integer_tmp1);
mpz_clear(_integer_tmp2);
mpz_clear(_integer_tmp3);

free(_integer_tmpstr0);

goto *r->pop(r);


/* Square root */

integer_sqrt:

mpz_init(_integer_tmp0);
mpz_init(_integer_tmp1);

mpz_set_str(_integer_tmp0,e->deref(e,1),10);
mpz_sqrt(_integer_tmp1,_integer_tmp0);

_integer_tmpint0 = mpz_sizeinbase(_integer_tmp1,10) + 2;
_integer_tmpstr0 = malloc(_integer_tmpint0);
gmp_snprintf(_integer_tmpstr0,_integer_tmpint0,"%Zd",_integer_tmp1);

e->stack[e->top - 2]->destroy(e->stack[e->top - 2]);
e->stack[e->top - 2] = variable_create("gmp variable",_integer_tmpstr0);

mpz_clear(_integer_tmp0);
mpz_clear(_integer_tmp1);

free(_integer_tmpstr0);

goto *r->pop(r);


/* Equality */

integer_equal:

mpz_init(_integer_tmp0);
mpz_init(_integer_tmp1);

mpz_set_str(_integer_tmp0,e->deref(e,1),10);
mpz_set_str(_integer_tmp1,e->deref(e,2),10);
_integer_tmpint0 = mpz_cmp(_integer_tmp0,_integer_tmp1);

e->stack[e->top - 3]->destroy(e->stack[e->top - 3]);
if(_integer_tmpint0 == 0)
  e->stack[e->top - 3] = variable_create("gmp variable","true");
else
  e->stack[e->top - 3] = variable_create("gmp variable","false");

mpz_clear(_integer_tmp0);
mpz_clear(_integer_tmp1);

goto *r->pop(r);



/* Linux system calls */

int _linux_tmpint0 = 0;
int _linux_tmpint1;
int _linux_tmpint2;
int _linux_tmpint3;
int _linux_tmpint4;
int _linux_tmpint5;
int _linux_tmpint6;
int _linux_tmpint7;
int _linux_tmpint8;
int _linux_tmpint9;

char *_linux_tmpstr0;
char *_linux_tmpstr1;
char *_linux_tmpstr2;
char *_linux_tmpstr3;
char *_linux_tmpstr4;
char *_linux_tmpstr5;
char *_linux_tmpstr6;
char *_linux_tmpstr7;
char *_linux_tmpstr8;
char *_linux_tmpstr9;


/* write() */

linux_write:

_linux_tmpint0 = atoi(e->deref(e,3));
_linux_tmpint1 = atoi(e->deref(e,1));
_linux_tmpint2 = write(_linux_tmpint0,e->deref(e,2),_linux_tmpint1);

_linux_tmpstr0 = (char *)malloc(_linux_tmpint1 + 2);
snprintf(_linux_tmpstr0,_linux_tmpint1+1,"%d",_linux_tmpint2);

e->stack[e->top - 4]->destroy(e->stack[e->top - 4]); // wasteful? Why bother having anything there?
e->stack[e->top - 4] = variable_create("linux variable",_linux_tmpstr0);

free(_linux_tmpstr0);

goto *r->pop(r);


/* (bytesreceived,buffer) = read(filedescriptor,bytesrequested) */

linux_read:

_linux_tmpint0 = atoi(e->deref(e,2)); // file descriptor
_linux_tmpint1 = atoi(e->deref(e,1)); // buffer size

_linux_tmpstr0 = (char *)malloc(_linux_tmpint1); // output buffer

_linux_tmpint2 = read(_linux_tmpint0,_linux_tmpstr0,_linux_tmpint1); // bytes read

_linux_tmpint3 = snprintf(0,0,"%+d",_linux_tmpint2); // Courtesy of stack overflow's discussion 
_linux_tmpstr1 = (char *)malloc(_linux_tmpint3+1);
snprintf(_linux_tmpstr1,_linux_tmpint3,"%d",_linux_tmpint2); 

e->stack[e->top - 4]->destroy(e->stack[e->top - 4]); // write out size in bytes
e->stack[e->top - 4] = variable_create("linux variable num of bytes",_linux_tmpstr1);
e->stack[e->top - 3]->destroy(e->stack[e->top - 3]); // write out buffer -- what if it contains a zero byte, though!?
e->stack[e->top - 3] = variable_create("linux variable buffer",_linux_tmpstr0);

free(_linux_tmpstr0);
free(_linux_tmpstr1);

goto *r->pop(r);


/* exit() */

linux_exit:

// a bit of debug

_linux_tmpint0 = atoi(e->deref(e,1));

e->print(e);
a->print(a);
r->print(r);

variable_enumerate();

exit(_linux_tmpint0);


/* String functions */


int _string_tmpint0;
int _string_tmpint1;
int _string_tmpint2;
int _string_tmpint3;
int _string_tmpint4;
int _string_tmpint5;
int _string_tmpint6;
int _string_tmpint7;
int _string_tmpint8;
int _string_tmpint9;


char *_string_tmpstr0;
char *_string_tmpstr1;
char *_string_tmpstr2;
char *_string_tmpstr3;
char *_string_tmpstr4;
char *_string_tmpstr5;
char *_string_tmpstr6;
char *_string_tmpstr7;
char *_string_tmpstr8;
char *_string_tmpstr9;


/* (count) = length(string) */

string_length:

//printf("setting up string length:\n");
//e->print(e);

_string_tmpint0 = e->stack[e->top-1]->count-1;
//printf("This string '%s' has %d characters\n",e->stack[e->top-1]->value,_string_tmpint0);

_string_tmpstr0 = (char *)malloc(_string_tmpint0 + 1); // no negative numbers possible
snprintf(_string_tmpstr0,_string_tmpint0+1,"%d",_string_tmpint0);
//printf("Now, this string '%s' has '%s' characters\n",e->stack[e->top-1]->value,_string_tmpstr0);

e->stack[e->top - 2]->destroy(e->stack[e->top - 2]);
e->stack[e->top - 2] = variable_create("string length() variable",_string_tmpstr0);

free(_string_tmpstr0);

goto *r->pop(r);


}






