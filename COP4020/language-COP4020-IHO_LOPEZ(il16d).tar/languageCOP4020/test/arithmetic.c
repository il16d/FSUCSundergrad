_main:
e->allocate_constant(e,"1");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,"2");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,"12");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,3,1);
copy_to_evaluation(e,a,2,1);
r->push(r,&&_l000000);
goto integer_add;
_l000000:
e->deallocate(e,2,1);
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,4,1);
copy_to_evaluation(e,a,2,1);
r->push(r,&&_l000001);
goto integer_multiply;
_l000001:
e->deallocate(e,2,1);
copy_to_evaluation(e,a,2,1);
r->push(r,&&_l000002);
goto integer_multiply;
_l000002:
e->deallocate(e,2,1);
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,"0");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,2,1);
r->push(r,&&_l000003);
goto integer_sqrt;
_l000003:
e->deallocate(e,1,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,"x = ");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,", y = ");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,", z = ");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,", a = ");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,", b = ");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,", k = ");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_constant(e,"\n");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,7,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,7,1);
r->push(r,&&_l000004);
goto string_length;
_l000004:
e->deallocate(e,1,1);
r->push(r,&&_l000005);
goto linux_write;
_l000005:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,13,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,13,1);
r->push(r,&&_l000006);
goto string_length;
_l000006:
e->deallocate(e,1,1);
r->push(r,&&_l000007);
goto linux_write;
_l000007:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,6,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,6,1);
r->push(r,&&_l000008);
goto string_length;
_l000008:
e->deallocate(e,1,1);
r->push(r,&&_l000009);
goto linux_write;
_l000009:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,12,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,12,1);
r->push(r,&&_l000010);
goto string_length;
_l000010:
e->deallocate(e,1,1);
r->push(r,&&_l000011);
goto linux_write;
_l000011:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,5,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,5,1);
r->push(r,&&_l000012);
goto string_length;
_l000012:
e->deallocate(e,1,1);
r->push(r,&&_l000013);
goto linux_write;
_l000013:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,11,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,11,1);
r->push(r,&&_l000014);
goto string_length;
_l000014:
e->deallocate(e,1,1);
r->push(r,&&_l000015);
goto linux_write;
_l000015:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,4,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,4,1);
r->push(r,&&_l000016);
goto string_length;
_l000016:
e->deallocate(e,1,1);
r->push(r,&&_l000017);
goto linux_write;
_l000017:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,10,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,10,1);
r->push(r,&&_l000018);
goto string_length;
_l000018:
e->deallocate(e,1,1);
r->push(r,&&_l000019);
goto linux_write;
_l000019:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,3,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,3,1);
r->push(r,&&_l000020);
goto string_length;
_l000020:
e->deallocate(e,1,1);
r->push(r,&&_l000021);
goto linux_write;
_l000021:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,9,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,9,1);
r->push(r,&&_l000022);
goto string_length;
_l000022:
e->deallocate(e,1,1);
r->push(r,&&_l000023);
goto linux_write;
_l000023:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,2,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,2,1);
r->push(r,&&_l000024);
goto string_length;
_l000024:
e->deallocate(e,1,1);
r->push(r,&&_l000025);
goto linux_write;
_l000025:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,8,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,8,1);
r->push(r,&&_l000026);
goto string_length;
_l000026:
e->deallocate(e,1,1);
r->push(r,&&_l000027);
goto linux_write;
_l000027:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,1,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,1,1);
r->push(r,&&_l000028);
goto string_length;
_l000028:
e->deallocate(e,1,1);
r->push(r,&&_l000029);
goto linux_write;
_l000029:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
a->deallocate(a,13);
goto _exit;
