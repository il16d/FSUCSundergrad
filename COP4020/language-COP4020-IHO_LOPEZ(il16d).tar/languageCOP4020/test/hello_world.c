_main:
e->allocate_constant(e,"Hello, greetings, saluations world! (Yippee!)\n");
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
copy_to_evaluation(e,a,1,1);
r->push(r,&&_l000000);
goto string_length;
_l000000:
e->deallocate(e,1,1);
a->allocate(a,1);
assign(a,e,1,1);
e->deallocate(e,1,1);
e->allocate_out(e,1);
e->allocate_constant(e,"1");
copy_to_evaluation(e,a,2,1);
copy_to_evaluation(e,a,1,1);
r->push(r,&&_l000001);
goto linux_write;
_l000001:
e->deallocate(e,3,1);
e->deallocate(e,1,1);
a->deallocate(a,2);
goto _exit;
