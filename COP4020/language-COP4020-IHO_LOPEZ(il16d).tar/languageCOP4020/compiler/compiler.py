import sys
from parse import parse

def main():
	print(sys.argv)
	print(len(sys.argv))
	output_file = "out.c"
	
	temp_argv = []
	temp_argv_ = []
	
	for i in range(1, len(sys.argv)):
		# temp_argv[i] = sys.argv[i]
		temp_argv.append(sys.argv[i])
		# temp_argv_[i] = sys.argv[i]
		temp_argv_.append(sys.argv[i])
	for i in range(len(temp_argv)):
		print(temp_argv[i])
		# if temp_argv[i].split()[0] == 'o':
		if temp_argv[i] == "-o":
			# output_file = temp_argv[i]
			output_file = temp_argv[i+1]
			del temp_argv_[i]
			del temp_argv_[i]
			break
		else:
			usage("")
	print(output_file)
	open('error.txt', 'w')
	if output_file != "out.c":
		for i in range(len(temp_argv_)):
			# with open('error.txt', 'a+') as text_file:
				# text_file.write(temp_argv_[i])
			f_output = open(output_file, 'w+')
			print(temp_argv_[i])
			parse(temp_argv_[i], f_output)
	else:
		usage("Cannot open output file" + output_file)

def usage(str):
	with open('error.txt', 'a+') as text_file:
		text_file.write(str)
		text_file.write("Usage: compiler [-o outputfile] [libs] program")
	sys.exit(0)

if __name__ == "__main__":
    # execute only if run as a script
    main()