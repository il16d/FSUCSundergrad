
from lexer import fail

def new_label():
	label_counter = 0
	if label_counter > 1000000:
		fail("emit.c: new_label(): label counter exceeds 100000 (congratulations!)")

	ret = ""
	for i in range(10):
		try:
			temp = int(str(label_counter).split()[i])
			ret += str(temp)
		except:
			continue
	label_counter += 1
	return ret

def emit(instruction, int_list):

	if instruction == 'assign':
		print('assign(a,e,' + str(int_list) + ');')
	elif instruction == 'allocate_a':
		print('a->allocate(a,' + str(int_list) + ');')
	elif instruction == 'allocate_e':
		print('e->allocate_e(e,' + str(int_list) + ');')
	elif instruction == 'allocate_e_in':
		print('e->allocate_in(e,' + str(int_list) + ');')
	elif instruction == 'allocate_e_constant':
		print('e->allocate_constant(e,' + int_list + ');')
	elif instruction == 'allocate_e_out':
		print('e->allocate_out(e,' + str(int_list) + ');')
	elif instruction == 'deallocate_a':
		print('a->deallocate(a,' + str(int_list) + ');')
	elif instruction == 'deallocate_e':
		print('e->deallocate(e' + str(int_list) + ',1);')
	elif instruction == 'copy_e_a':
		print('copy_to_evaluation(e,a,' + str(int_list) + ',1);')
	elif instruction == 'copy_e_e':
		target = int_list[0]
		source = int_list[1]
		print('e->copy_e_e(e' + str(target) + ',' + str(source) + ',1);')
	elif instruction == 'dup_e':
		print('e->dup(e,' + str(int_list) + ',1)')
	elif instruction == 'function_invocation':
		replace_period_with_underscore(int_list)
		label = new_label()
		print('r->push(r,' + label + ');')
		print('goto' + int_list + ';')
		print(label)
	elif instruction == 'function_prologue':
		replace_period_with_underscore(int_list)
		print('\t\t // function ' + int_list + ' begins here' + int_list)
	elif instruction == 'function_epilogue':
		replace_period_with_underscore(int_list)
		print('goto *r->pop(r); //function ' + int_list + 'ends here')
	elif instruction == 'boolean_assert':
		print('_p = e->deref(e,1);')
		print('if((strcmp(_p,\"0\")==0)||(strcmp(_p,\"false\")==0))goto' + int_list)
		print('e->deallocate(e,1,1);')
	elif instruction == 'boolean_assert_failed':
		print(int_list)
		print('e->deallocate(e,1,1)')
	elif instruction == 'label':
		print(int_list)
	elif instruction == 'goto_':
		print('goto ' + int_list)
	else:
		print("OOPSS --> received an emit for an unimplemented instruction!")
		fail("Received emit for an unimplemented instruction.")

def replace_period_with_underscore(string1):
	temp_string = string1.split()
	result = ""
	flag = 0
	for i in range(len(temp_string)):
		if temp_string[i] == '.':
			flag = i
			break
	for i in range(flag, len(temp_string)):
		result += temp_string[i]