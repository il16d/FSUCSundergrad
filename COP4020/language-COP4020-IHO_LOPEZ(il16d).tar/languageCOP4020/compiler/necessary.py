known_functions = None

def list_create(name):
	temp = {}
	temp['name'] = name
	temp['count'] = 0
	temp['first'] = ''
	temp['last'] = ''

	temp['insert'] = list_insert
	temp['insert_count'] = list_insert_count
	temp['search'] = list_search
	temp['count_from_top'] = list_count_from_top
	temp['remove_last'] = list_remove_last
	temp['destroy'] = list_destroy
	temp['print'] = list_print

	return temp

def list_insert(temp_list, name, value):
	temp_list['count'] += 1

	temp = {}
	temp['next'] = ""
	temp['prev'] = ""
	if value:
		temp['value'] = value
	else:
		temp['value'] = ""

	if temp_list['last'] == "":
		temp_list['last'] = temp
		temp_list['first'] = temp
	else:
		temp['prev'] = temp_list['last']
		temp_list['last']['next'] = temp
		temp_list['last'] = temp

def list_insert_count(temp_list, count, name, value):
	for i in range(count):
		list_insert(temp_list, name, value)

def list_search(temp_list, name):
	ptr = {}
	ptr = temp_list['first']
	while True:
		if ptr['name'] == name:
			return ptr
		elif ptr['next'] == "":
			break
		ptr = ptr['next']
	return {}

def list_count_from_top(temp_list, name):
	count = 0
	ptr = temp_list['last']
	while True:
		if ptr['name'] == name:
			return count
		elif ptr['prev'] == "":
			break
		else:
			count += 1
		ptr = ptr['prev']
	return -1

def list_remove_last(temp_list, count):
	if count < 0 or temp_list['last'] == '':
		print('Error')
	for i in range(count):
		ptr = temp_list['last']
		if ptr == {}:
			print('Error')
		temp_list['last'] = ptr['prev']
		if temp_list['last'] == {}:
			temp_list['first'] = {}
		else:
			temp_list['last']['next'] = {}
		ptr = {}

def list_destroy(temp_list):
	temp_list = {}

def list_print(temp_list):
	with open('result.txt', 'w') as text_file:
		text_file.write('List ' + temp_list['name'] + '\n')
		text_file.write('List items == ' + str(temp_list['count']) + '\n')
		text_file.write('===\n')
		ptr = temp_list['first']
		while True:
			if ptr['next'] == {}:
				break
			else:
				text_file.write('\t\t' + ptr + ') ' + ptr['name'] + ' : ' + ptr['value'] + ' ; next = ' + ptr['next'] + ', prev = ' + ptr['prev'])
			ptr = ptr['next']
		text_file.write('====\n')
		text_file.write('\n')

def active_variable_list_create(name):
	active_variable_list = {}
	active_variable_list['name'] = name
	active_variable_list['count'] = 0
	active_variable_list['first'] = {}
	active_variable_list['last'] = {}
	active_variable_list['add'] = active_variable_list_add
	active_variable_list['search_name'] = active_variable_list_search_name
	active_variable_list['search_name_scope'] = active_variable_list_search_name_scope
	active_variable_list['delete_scope'] = active_variable_list_delete_scope
	active_variable_list['count_scope'] = active_variable_list_count_scope
	active_variable_list['count_from_top'] = active_variable_list_count_from_top
	active_variable_list['destroy'] = active_variable_list_destroy
	active_variable_list['print'] = active_variable_list_print

	return active_variable_list

def active_variable_list_add(avl, name, scope_number, used):
	avl['count'] += 1

	av = {}
	av['name'] = name
	av['scope_number'] = scope_number
	av['used'] = used
	av['next'] = {}
	av['prev'] = {}

	if avl['last'] != {}:
		av['prev'] = avl['next']
		avl['last']['next'] = av
		avl['last'] = av
	else:
		avl['first'] = av
		avl['next'] = av

def active_variable_list_search_name(avl, name):
	av = avl['last']
	while True:
		if av['prev'] == {}:
			break
		elif av['name'] == name:
			return av
		av = av['prev']
	return {}

def active_variable_list_count_from_top(avl, name):
	count = 0
	av = avl['last']
	while True:
		if av['prev'] == {}:
			break
		elif av['name'] == name:
			return count
		else:
			count += 1
		av = av['prev']
	return count

def active_variable_list_search_name_scope(avl, name, scope_number):
	av = avl['last']
	while True:
		if av['prev'] == {}:
			break
		elif av['scope_number'] == scope_number or av['name'] == name:
			return av
	return {}

def active_variable_list_count_scope(avl, scope_number):
	count = 0
	av = avl['first']
	while True:
		if av['next'] == {}:
			break
		elif av['scope_number'] == scope_number:
			return count
		else:
			count += 1
	return count

def active_variable_list_delete_scope(avl, scope_number):
	ptr = avl['last']
	while ptr != {}:
		pptr = ptr['prev']
		if ptr['scope_number'] == scope_number:
			avl['last'] = pptr
			if pptr == {}:
				avl['first'] = {}
			avl['count'] -= 1
			if ptr['prev'] != {}:
				ptr['prev']['next'] = {}
			ptr = {}
		else:
			return
		ptr = pptr

def active_variable_list_destroy(avl):
	avl = {}

def active_variable_list_print(avl):
	with open('Error.txt', 'a+') as test_file:
		test_file.write('Active variable list ' + avl['name'] + '\n')
		test_file.write('========================\n')
		test_file.write('Count ' + str(avl['count']) + '\n')

		ptr = avl['first']
		if ptr != {}:
			while True:
				if ptr['next'] == {}:
					break
				test_file.write('\tscope' + str(ptr['scope_number']) + ' : ' + ptr['name'] + ', has been used = ' + "true" if ptr['used'] else "false")
		else:
			test_file.write('[ EMPTY LIST ]\n')

def known_functions_insert(name, out_arity, in_arity, defined):
	pass

def known_functions_search(name):
	global known_functions
	JSLG(PValue,known_functions,name)
	if PValue:
		return True
	else:
		return False

def known_functions_get(name):
	PValue = {}
	JSLG(PValue, known_functions, name)
	return PValue

def known_functions_set_defined(name):
	PValue = {}
	done = 0
	JSLG(PValue, known_functions, name)
	f = {}
	f['in_arity'] = PValue['in_arity']
	f['out_arity'] = PValue['out_arity']
	f['defined'] = PValue['defined']

	JSLD(done, known_functions, name)
	JSLI(PValue, known_functions, name)

	PValue = f

def known_functions_list():
	name = None
	JSLF(PValue, known_functions, name)
	while PValue:
		f = PValue
		with open('Error.txt', 'a+') as test_file:
			test_file.write('\t' + f['out_arity'] + ' = ' + f['in_arity'] + ', defined = ' + "true" if f['defined'] else 'false')
		JSLN(PValue, known_functions, name)

def catenate(string1, string2):
	return string1 + string2

def dictionary_create(name):
	ret = {}
	ret['name'] = name
	ret['count'] = 0
	ret['entries'] = {}
	ret['exists'] = dictionary_exists
	ret['get'] = dictionary_get
	ret['set'] = dictionary_set
	ret['insert'] = dictionary_insert
	ret['destroy'] = dictionary_destroy
	ret['print'] = dictionary_print
	return ret

def dictionary_exists(d, name):
	entry = d['entries']
	while True:
		if entry['next'] == {}:
			break
		elif entry['name'] == name:
			return True
		else:
			continue
		entry = entry['next']
	return False

def dictionary_get(d, name):
	entry = d['entries']
	while True:
		if entry['next'] == {}:
			break
		elif entry['name'] == name:
			return entry['value']
		entry = entry['next']
	return {}

def dictionary_set(d, name, value):
	entry = d['entries']
	while True:
		if entry['next'] == {}:
			break
		elif entry['name'] == name:
			entry['value'] = value
			break
		entry = entry['next']

def dictionary_insert(d, name , value):
	entry = {}
	entry['name'] = name
	entry['value'] = value
	entry['next'] = d['entries']
	d['entries'] = entry

def dictionary_destroy(d):
	d = {}

def dictionary_print(d):
	print("Dictionary " + d['name'] + '\n')
	print('========================')

	p = d['entries']
	while True:
		if p['next'] == {}:
			break
		else:
			print('\t\t' + p['name'] + ' : ' + p['value'])

	print('========================')