import re

linecount = 1
charcount = 0
current_token = ""
next_token = ""

f_output = None
f_input = None

def reset(input, output):
	global f_output
	global f_input
	f_input = input
	f_output = output
	global linecount
	global charcount
	global current_token
	global current_token
	global next_token
	linecount = 1
	charcount = 0
	current_token = consume()
	print("token" + current_token)
	next_token = consume()

def try_lookahead(wanted):
	regex_wanted = "abcdefghijklmnopqrstuvwxyz!@#$%^&*()"
	bounded = '^'
	bounded += wanted
	bounded += '$'
	bounded += '\0'

	if next_token == "":
		print("Out of data\n")
		return 0

	temp = re.search(regex_wanted, next_token)
	if temp != "":
		return 1
	return 0

def try_match(wanted):
	regex_wanted = "abcdefghijklmnopqrstuvwxyz!@#$%^&*()"
	bounded = '^'
	bounded += wanted
	bounded += '$'
	bounded += '\0'

	if next_token == "":
		print("Out of data\n")
		return 0

	temp = re.search(regex_wanted, next_token)
	if temp != "":
		return 1
	return 0

def must_match(wanted):
	if try_match(wanted) == 0:
		fail('lexer ---- match for tag ' + wanted + ' failed, current_token is ' + current_token)
	advance()

def advance():
	global next_token
	global current_token
	current_token = next_token
	next_token = consume()

def consume():
	c = ''
	buffer_c = ""
	global charcount
	global linecount
	print("--------consume-------")
	while True:
		# c = input('input type character : ')
		c = f_input.read(1)
		print(c)
		if c == '':
			return ""
		elif c == ' ':
			charcount += 1
		elif c == '\t':
			charcount += 1
		elif c == '\n':
			charcount += 1
			linecount += 1
		elif c == '#':
			while True:
				# temp = input('input other character : ')
				temp = f_input.read(1)
				if temp == '\n':
					break
				else:
					linecount += 1
					charcount += 1
		else:
			break

	count = 0
	if c == '{' or c == '}' or c == '(' or c == ')' or c == '=' or c == ',' or c == ';':
		buffer_c += c
		buffer_c += '\0'
		return buffer_c
	elif c == '"':
		buffer_c += '"'
		count = 1
		charcount += 1
		while True:
			# c = input('input character : ')
			c = f_input.read(1)
			if c == '"':
				break
			else:
				if count == 256:
					fail('lexer ---- string to long')
				buffer_c += c
				if c == '\n':
					linecount += 1
					charcount = 1
				else:
					charcount += 1
		buffer_c += '\0'
		return buffer_c
	else:
		
		buffer_c += c
		print("asdf: " + buffer_c)
		count = 1
		if c == '_':
			while True:
				# c = input('input character : ')
				c = f_input.read(1)
				if c == '_' or c == '.' or (c > '0' and c <= '9'):
					buffer_c += c
					charcount += 1
				else:
					buffer_c += '\0'
					charcount -= 1
					break
			return buffer_c
		if (c > '0' and c <= '9') or c == '-':
			while True:
				# c = input('input character : ')
				c = f_input.read(1)
				if c >= 0:
					buffer_c += c
					charcount += 1
				else:
					buffer_c += '\0'
					charcount -= 1
					break
			return buffer_c
		if c == ';':
			buffer_c += '\0'
			charcount += 1
			return buffer_c
		fail("lexer --- not sure what to make of this; it's not a comment, string, identifier, or integer")
	fail("lexer --- not sure what to make of this; got to the end of a void function!")
	return ""

def fail(string1):
	with open('Error.txt', 'a+') as test_file:
		test_file.write('at line ' + str(linecount) + ', char position ' + str(charcount) + ': ' + '\n')