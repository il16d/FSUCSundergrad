from lexer import reset
from necessary import active_variable_list_create
from necessary import list_create
from necessary import catenate
from necessary import known_functions_search
from necessary import known_functions_list
from necessary import known_functions_get
from necessary import known_functions_set_defined
from lexer import try_match
from lexer import must_match
from lexer import advance
from lexer import try_lookahead
from lexer import fail
from emit import emit
from emit import new_label

known_functions = None
avl = None
active_parameter_list = None
current_scope_number = -1
identifier = "[a-zA-Z][a-zA-Z0-9._]*"
number = "([0-9]+)|(-[0-9]+)"
current_token = None
next_token = None
current_module_name = None

f_output = None
f_input = None
def parse(filename, output):
	global f_output
	global f_input
	f_output = output
	try:
		# with open(filename, 'r') as text_file:
			# text_file.readlines()
		f_input = open(filename, 'r')
		with open('error.txt', 'a+') as text_file:
			text_file.write("\nparsing " + filename + "\n")
	except:
		with open('error.txt', 'a+') as text_file:
			text_file.write("Failed to open input file " + filename)

	reset(f_input, f_output)
	global avl
	avl = active_variable_list_create('Active variables')
	main_or_module_or_exports()
	with open('Error.txt', 'a+') as text_file:
		text_file.write('Recognized ' + filename)

def main_or_module_or_exports():
	if try_match('main'):
		advance()
		global current_module_name
		current_module_name = 'main'
		declarations_section()
		program_section()
		functions_section()
	elif try_match('module'):
		advance()
		current_module_name = current_token
		must_match(identifier)
		if try_match('exports'):
			exports_section()
		elif try_match('imports'):
			imports_section()
			declarations_section()
			functions_section()

def imports_section():
	must_match('imports')
	must_match('[{]')
	module_list()
	must_match('[}]')

def module_list():
	while try_match('[}]') == 0:
		must_match(identifier)
		must_match(';')

def program_section():
	active_parameter_list = list_create('active parameter list for main')
	emit('label', '_main')
	
	must_match('program')
	statement_block()

	emit('goto_', '_exit')
	active_parameter_list['destroy'](active_parameter_list)
	active_parameter_list = {}

def statement_list():
	while try_match('[}]') == 0:
		if try_match('var') == 1:
			variable_declaration()
		elif try_match('[{]') == 1:
			statement_block()
		elif try_match('if') == 1:
			if_else_statement()
		elif try_match('while') == 1:
			while_statement()
		elif try_match('[(]') == 1:
			assignment_statement()
		elif try_match(identifier):
			if try_lookahead('[(]') == 1:
				how_many = function_call()
				must_match(';')
				emit('deallocate_e', how_many)
				active_parameter_list.remove_last(active_parameter_list)
			elif try_lookahead('='):
				assignment_statement()
			else:
				fail('statement_list: expected a statement')
		else:
			fail('statement_list: expected a statement')

def functions_section():
	must_match('functions')
	must_match('[{]')
	function_list()
	must_match('[}]')

def function_list():
	while try_match('[}]') == 0:
		function()

def function_declaration_list():
	while try_match('[}]') == 0:
		function_declaration()

def function_declaration():
	must_match('[(]')
	out = identifier_list()
	must_match('[)]')
	must_match('=')

	dot_token = catenate(current_module_name, '.')
	name = catenate(dot_token, current_token)

	must_match(identifier)
	must_match('[(]')
	in_list = identifier_list()
	must_match('[)]')
	must_match(';')

	f = {}
	f['out_arity'] = out['count']
	f['in_arity'] = in_list['count']
	f['defined'] = False

	JSLI(PValue, f, name)
	if f == PJERR:
		fail("parser.c: function_declaration(): Judy array insert failed")
	PValue = f

def exports_section():
	must_match('exports')
	must_match('[{]')
	function_declaration_list()
	must_match('[}]')

def declarations_section():
	must_match("declarations")
	must_match("[{]")
	function_declaration_list()
	must_match("[}]")

def variable_declaration():
	must_match('var')

	identifier_count = 0
	singleton = 0
	name = ""
	l = {}

	if try_match(identifier) == 1:
		name = current_token
		identifier_count = 1
		singleton = 1
		advance()
	else:
		must_match('[(]')
		l = identifier_list()
		must_match('[)]')
		identifier_count = l['count']

	must_match('=')
	expression_out_arity = expression()
	must_match(';')

	if identifier_count != expression_out_arity:
		fail('parser.c: variable declaration is for ' + str(identifier_count) + ' identifiers, but the expression has ' + str(expression_out_arity) + ' out arity')

	if singleton == 1:
		av = avl['search_name_scope'](avl,name,current_scope_number)
		if av:
			fail("parser.c: variable_declaration(): redefinition of variable '" + name + "' in same scope")
		else:
			nvp = l['first']
			while True:
				if nvp['next'] == {}:
					break
				else:
					av = avl['search_name_scope'](avl,nvp['name'],current_scope_number)
					if av:
						fail("parser.c: variable_declaration(): redefinition of variable '" + name + "' in same scope")
	if singleton == 1:
		avl['add'](avl, name, current_scope_number, False)
		emit('allocate_a', 1)
		emit('assign', 1)
		emit('deallocate_e', 1)
		active_parameter_list['remove_last'](active_parameter_list)
	else:
		nvp = l['last']
		while True:
			if nvp['prev'] == {}:
				break
			else:
				avl['add'](avl, nvp['name'], current_scope_number, False)
				emit('allocate_a', 1)
				emit('assign', 1)
				emit('deallocate_e', 1)
				active_parameter_list['remove_last'](active_parameter_list)

def expression():
	if try_match(number) == 1:
		emit('allocate_e_constant', current_token)
		active_parameter_list['insert'](active_parameter_list)
		advance()
		return 1
	elif try_match('\".*"'):
		emit('allocate_e_constant', current_token + 1)
		active_parameter_list['insert'](active_parameter_list)
		advance()
		return 1
	elif try_match(identifier):
		if try_lookahead('[(]'):
			ret = function_call()
			return ret
		else:
			where = 0
			found = 0
			if avl['search_name'](avl, current_token):
				found = 1
				where = avl['count_from_top'](active_parameter_list, current_token)
				emit('copy_e_a', where + 1)
				active_parameter_list['insert'](active_parameter_list)
			if found != 0 and active_parameter_list['search'](active_parameter_list, current_token):
				found = 2
				where = active_parameter_list['count_from_top'](active_parameter_list, current_token)
				emit('dup_e', where + 1)
				active_parameter_list['insert'](active_parameter_list,"(anonymous copy of evaluation variable)",current_token)
			advance()
			return 1

	else:
		fail("parser.c: expression(): That's not an expression")
	fail("parser.c: expression(): fell through, shouldn't do that.")
	return 0

def function_call():
	function_name = current_token
	must_match(identifier)

	if '.' in function_name:
		module_with_dot = catenate(current_module_name, '.')
		testname = catenate(module_with_dot, function_name)
		function_name = testname
	if not known_functions_search(function_name):
		known_functions_list()
		fail("parser.c: function_call(): unknown function name " + function_name)

	f = known_functions_get(function_name)
	emit('allocate_e_out', f['out_arity'])
	active_parameter_list['insert_count'](active_parameter_list, f['out_arity'], "out variable","")

	must_match('[(]')
	argcount = argument_list()
	must_match('[)]')

	if f['in_arity'] != argcount:
		fail("parser.c: function call '%s' specifies an in arity of %d, but there are %d arguments in the argument list" + function_name + f['in_arity'] + argcount)

	emit('function_invocation', function_name)
	emit('deallocate_e', f['in_arity'])
	active_parameter_list['remove_last'](active_parameter_list, f['in_arity'])
	return f['out_arity']

def if_else_statement():
	else_block_start= new_label()
	else_block_end = new_label()

	must_match('if')
	must_match('[(]')

	emit('boolean_assert', else_block_start)
	active_parameter_list['remove_last'](active_parameter_list,1)

	must_match('[)]')
	statement_block()

	emit('goto_', else_block_end)
	emit('boolean_assert_failed', else_block_start)

	if try_match('else') == 1:
		must_match('else')
		statement_block()

	emit('label', else_block_end)

def while_statement():
	statement_block_start = new_label()
	statement_block_exit = new_label()

	must_match('while')
	must_match('[(]')

	emit('label', statement_block_start)
	arity = expression()

	if arity != 1:
		fail("parser.c: while(): there should be one boolean item on the stack, but there are instead %d\n" %arity)
	emit('boolean_assert', statement_block_exit)
	active_parameter_list['remove_last'](active_parameter_list, 1)

	must_match('[)]')
	statement_block()

	emit('goto_', statement_block_start)
	emit('label', statement_block_exit)
	emit('deallocate_e', 1)

def function():
	must_match("[(]")
	params_out = identifier_list()
	must_match("[)]")
	must_match("=")

	function_name = current_token
	if '.' in function_name:
		module_with_dot = catenate(current_module_name, '.')
		testname = catenate(module_with_dot, function_name)
		function_name = testname
	if not known_functions_search(function_name):
		known_functions_list()
		fail("parser.c: function_call(): there was no declaration in exports or declarations sections for this function %s" %function_name)

	known_functions_set_defined(function_name)
	emit('function_prologue', function_name)

	must_match(identifier)
	must_match('[(]')
	params_in = identifier_list()
	must_match('[)]')

	active_parameter_list = list_create('active parameter list for function')
	param = params_out['first']
	while True:
		if param['next'] == {}:
			break
		else:
			active_parameter_list['insert'](active_parameter_list, param['name'], 'out')

	while True:
		if param['next'] == {}:
			break
		else:
			active_parameter_list['insert'](active_parameter_list, param['name'], 'in')

	statement_block()

	emit('function_epilogue', function_name)
	params_out['destroy'](params_out)
	params_in['destroy'](params_in)
	active_parameter_list['destroy'](active_parameter_list)

def assignment_statement():
	identifier_count = 0
	l = {}

	if try_match(identifier) == 1:
		identifier_count = 1
		l = list_create('identifier list')
		l['insert'](l, current_token, '')
		advance()
	else:
		must_match('[(]')
		l = identifier_list()
		must_match('[)]')
		identifier_count = l['count']
	must_match('=')
	expression_out_arity = expression()
	must_match(';')

	if identifier_count != expression_out_arity:
		fail("parser.c: assignment is to %d identifiers, but the expression has %d out arity", identifier_count, expression_out_arity)

	id_list_nvp = l['last']
	while True:
		if id_list_nvp[prev] == {}:
			break
		else:
			av = av1['search_name'](avl, id_list_nvp['name'])
			if av:
				how_far = avl['count_from_top'](avl, id_list_nvp['name'])
				emit('assing', how_far + 1)
				emit('deallocate_e', 1)
				active_parameter_list['remove_last'](active_parameter_list, 1)
			else:
				params_nvp = active_parameter_list['search'](active_variable_list, id_list_nvp['name'])
				if params_nvp:
					if params_nvp['value'] == 'out':
						how_far = active_parameter_list['count_from_top']('active_parameter_list', id_list_nvp[name])
						emit('copy_e_a', how_far + 1, 1)
						emit('deallocate_e', 1)
						active_parameter_list['remove_last'](active_parameter_list, 1)
					else:
						fail("parser.c: assignment(): variable '%s' refers to a non-out paramter",id_list_nvp['name'])
				else:
					fail("parser.c: assignment(): variable '%s' not defined",id_list_nvp['name'])
	if l:
		l['destroy'](l)

def identifier_list():
	l = list_create('identifier_list')
	while try_match('[)]') == 0:
		l['insert'](l, current_token, '')
		must_match(identifier)
		if try_match('[)]') == 1:
			pass
		else:
			must_match(',')
	return l

def argument_list():
	arity_count = 0
	while try_match('[)]') == 0:
		arity_count += expression()
		if try_match('[)]') == 1:
			pass
		else:
			must_match(',')
	return arity_count

def statement_block():
	must_match('[{]')

	current_scope_number += 1
	statement_list()
	must_match('[}]')

	active_count = al['count_scope'](avl, current_scope_number)
	avl['delete_scope'](avl, current_scope_number)

	if active_count:
		emit('deallocate_a', active_count)

	current_scope_number -= 1



