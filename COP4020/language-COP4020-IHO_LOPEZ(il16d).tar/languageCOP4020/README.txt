Iho Lopez Tobi
il16d

Readme:

For this project I decided to try my best at the python implementation of the compiler with the very basic understanding I had of the language and the many different topic we have touched on in class. To attempt this project   I looked over the implementation of the C files that were in the compiler folder and translated them in to python syntax. Many bugs and errors arise as the two languages are very different from each other. After the proper implementation and the proper fix of the syntax errors I am not sure of what I am not doing properly as I am unable to actually test the code by running make from inside the test folder. Every time I try to run make I get an output to my screen and then I get an error coming from within the fib-out.c file that does not allow me to actually proceed to further test the code as I do not know how to fix this. To run and test the code simply run make inside the test folder as the makefile has been modifies to call the new compiler. 

Thank you so much for a great semester and for the great lectures that allowed me to pursue and get this degree at Florida State University. It has been a great pleasure to learn from you. 
