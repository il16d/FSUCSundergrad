// external
void fail(const char *x, ...);

