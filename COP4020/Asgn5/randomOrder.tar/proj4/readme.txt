To invoce randomOrder.cpp use command g++ randomOrder.cpp
To invoce randomOrder.hs use command ghc randomOrder.hs
