package com.example.tictacnole;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class MainActivity2 extends AppCompatActivity implements View.OnClickListener {




    private CustomButton[][] buttons = new CustomButton[3][3];
    private ArrayList<CustomButton> buttonsPlayed1 = new ArrayList<>();  //As player1 clicks adds those buttons
    private ArrayList<CustomButton> buttonsPlayed2 = new ArrayList<>();  //As player1 clicks adds those buttons


    boolean player1Turn = true;




    private int roundCount;

    private int player1Points;
    private int player2Points;

    private TextView textViewPlayer1;
    private TextView textViewPlayer2;

    boolean isPlayerVsPlayer = true;


    private static int inBetween(int x, int y) {
        return (int) (x + y) / 2;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        textViewPlayer1 = findViewById(R.id.text_view_p1); //you
        textViewPlayer2 = findViewById(R.id.text_view_p2); //computer


        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                String buttonID = "button_" + i + j;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                buttons[i][j] = findViewById(resID);
                buttons[i][j].setOnClickListener(this);
                try {
                    buttons[i][j] = findViewById(resID);
                    buttons[i][j].setOnClickListener(this);

                    //Set buttons row and columns
                    buttons[i][j].setRow(i);
                    buttons[i][j].setColumn(j);

                } catch (ClassCastException exc) {
                    Log.println(Log.ERROR, "Error", exc.getMessage());
                }


            }
        }


        Button buttonReset = findViewById(R.id.button_reset);
        buttonReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetGame();
            }
        });


        //Go back to player mode if desired
        Button buttonback = (Button) findViewById(R.id.button_computer);
        buttonback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish();

            }
        });


    } //end of the  protected void


    @Override
    public void onClick(View v) {
        if (!((Button) v).getText().toString().equals("")) {
            return;
        }

        //Vs computer
        Log.d("Debug", "");
        ((Button) v).setText("X");
        buttonsPlayed1.add(((CustomButton) v));
        //Check for win
        if (checkForWin(copyBoard())) {
            player1Wins();
            return; //Skip everything else in this function because there is a winner
        }
        player1Turn = false;  //Needed by check for win


        //Computer logic - play 3 corners

        //1 Next move is win for computer
        CustomButton nextMove = checkNextMoveWin(false);
        if (nextMove != null) {
            Log.d("Debug", "Computer next move is win");
            int x = nextMove.getRow();
            int y = nextMove.getColumn();

            buttons[x][y].setText("O");
            buttonsPlayed2.add(buttons[x][y]);

            processWin();
            return;
        }
        //2 Block player win
        nextMove = checkNextMoveWin(true);   //Player next move is win
        if (nextMove != null) {
            Log.d("Debug", "Player next move is win");
            int x = nextMove.getRow();
            int y = nextMove.getColumn();

            buttons[x][y].setText("O");         //Do move to block
            buttonsPlayed2.add(buttons[x][y]);

            processWin();
            return;

        }

        //3 When 3 items played find available middle buttons (buttons in between corners)
        if (buttonsPlayed2.size() == 3) {
            Log.d("Debug", "size 3");

            int x1, y1, z1;  //Winning
            int x2, y2, z2;  //Winning

            CustomButton b1 = buttonsPlayed2.get(0);
            CustomButton b2 = buttonsPlayed2.get(1);
            CustomButton b3 = buttonsPlayed2.get(2);


            //Rows
            x1 = inBetween(b1.getRow(), b2.getRow());
            y1 = inBetween(b1.getRow(), b3.getRow());
            z1 = inBetween(b3.getRow(), b2.getRow());

            //Columns
            x2 = inBetween(b1.getColumn(), b2.getColumn());
            y2 = inBetween(b1.getColumn(), b3.getColumn());
            z2 = inBetween(b3.getColumn(), b2.getColumn());


            if (!buttonsPlayed2.contains(buttons[x1][x2]) && !buttonsPlayed1.contains(buttons[x1][x2])) {
                //Winning option 1

                buttons[x1][x2].setText("O");
                buttonsPlayed2.add(buttons[x1][x2]);
            } else if (!buttonsPlayed2.contains(buttons[y1][y2]) && !buttonsPlayed1.contains(buttons[y1][y2])) {
                //Winning option 2

                buttons[y1][y2].setText("O");
                buttonsPlayed2.add(buttons[y1][y2]);
            } else if (!buttonsPlayed2.contains(buttons[z1][z2]) && !buttonsPlayed1.contains(buttons[z1][z2])) {
                //Winning option 3

                buttons[z1][z2].setText("O");
                buttonsPlayed2.add(buttons[z1][z2]);
            }

            //Check for computer win
            if (checkForWin(copyBoard())) {
                player2Wins();
                return; //Skip everything else in this function because there is a winner
            }
        } else {
            //4 computer move until 3 corners are occupied
            Log.d("Debug", "less than 3");
            if (!buttonsPlayed2.contains(buttons[0][0]) && !buttonsPlayed1.contains(buttons[0][0])) {
                //Top left
                buttons[0][0].setText("O");
                buttonsPlayed2.add(buttons[0][0]);

            } else if (!buttonsPlayed2.contains(buttons[2][2]) && !buttonsPlayed1.contains(buttons[2][2])) {
                //Bottom right
                buttons[2][2].setText("O");
                buttonsPlayed2.add(buttons[2][2]);
            } else if (!buttonsPlayed2.contains(buttons[0][2]) && !buttonsPlayed1.contains(buttons[0][2])) {
                //Top right
                buttons[0][2].setText("O");
                buttonsPlayed2.add(buttons[0][2]);
            } else if (!buttonsPlayed2.contains(buttons[2][0]) && !buttonsPlayed1.contains(buttons[2][0])) {
                //Bottom left
                buttons[2][0].setText("O");
                buttonsPlayed2.add(buttons[2][0]);
            }

        }
        player1Turn=true;

    processWin();

}



    public void processWin(){
        roundCount++;
        Log.d("DEBUG", "Round: "+roundCount);

        //Checks if there is a winner
        if (checkForWin(copyBoard())) {
            if (player1Turn) {
                player1Wins();
            } else {
                player2Wins();
            }

            buttonsPlayed1.clear();
            buttonsPlayed2.clear();

        } else if (roundCount == 9 && isPlayerVsPlayer) {
            draw();
        } else if(roundCount==5 && isPlayerVsPlayer){
            draw();     //Draw in case of vs computer
        }


    }


    //Check if next move is a win and returns that win(false is computer next win, true is player)
    private CustomButton checkNextMoveWin(boolean isPlayerTurn){
        //Set whose turn it is
        String mark="";
        if(isPlayerTurn)
            mark="X";
        else
            mark="O";

        //Copy board
        String[][] field = copyBoard();


        //For every possible move
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if(field[i][j].equals("")){
                    //Make move

                    field[i][j]=mark;

                    //If win, return as CustomButton
                    if(checkForWin(field)){
                        CustomButton b=new CustomButton(this);
                        b.setRow(i);
                        b.setColumn(j);
                        b.setMark("O");
                        return b;
                    }
                    else {
                        //If not, clear last move
                        field[i][j]="";

                    }
                }
            }
        }


        return null;        //No move results in win

    }

    //Separate copy board to be reusable
    private String[][] copyBoard(){
        String[][] field = new String[3][3];

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                field[i][j] = buttons[i][j].getText().toString();
            }
        }
        return field;
    }

    //Checks for winner, field is copy board
    private boolean checkForWin(String[][] field) {


        for (int i = 0; i < 3; i++) {
            if (field[i][0].equals(field[i][1])
                    && field[i][0].equals(field[i][2])
                    && !field[i][0].equals("")) {
                return true;
            }
        }

        for (int i = 0; i < 3; i++) {
            if (field[0][i].equals(field[1][i])
                    && field[0][i].equals(field[2][i])
                    && !field[0][i].equals("")) {
                return true;
            }
        }

        if (field[0][0].equals(field[1][1])
                && field[0][0].equals(field[2][2])
                && !field[0][0].equals("")) {
            return true;
        }

        if (field[0][2].equals(field[1][1])
                && field[0][2].equals(field[2][0])
                && !field[0][2].equals("")) {
            return true;
        }

        return false;
    }



    private void player1Wins() { //they are void
        player1Points++;
        Toast.makeText(this, "You Win!", Toast.LENGTH_SHORT).show();
        updatePointsText();
        resetBoard();
        player1Turn=false;

    }

    private void player2Wins() {
        player2Points++;
        Toast.makeText(this, "The Computer Wins!", Toast.LENGTH_SHORT).show();
        updatePointsText();
        resetBoard();
        player1Turn=true;

    }

    private void draw() {
        Toast.makeText(this, "Draw!", Toast.LENGTH_SHORT).show();

        resetBoard();
        if (player1Turn==true)
        {
            player1Turn=false;
        }else{
            player1Turn=true;
        }
    }


    private void updatePointsText() {
        textViewPlayer1.setText("Player 1: " + player1Points);
        textViewPlayer2.setText("Computer: " + player2Points);
    }


    private void resetBoard() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setText("");
            }
        }

        roundCount = 0;
        player1Turn = true;

        buttonsPlayed1.clear();     //Reset player and computer buttons click during Player vs Computer
        buttonsPlayed2.clear();


    }


    private void resetGame() {
        player1Points = 0;
        player2Points = 0;
        buttonsPlayed1.clear();     //Reset player and computer buttons click during Player vs Computer
        buttonsPlayed2.clear();
        updatePointsText();
        resetBoard();
    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putInt("roundCount", roundCount);
        outState.putInt("player1Points", player1Points);
        outState.putInt("player2Points", player2Points);
        outState.putBoolean("player1Turn", player1Turn);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        roundCount = savedInstanceState.getInt("roundCount");
        player1Points = savedInstanceState.getInt("player1Points");
        player2Points = savedInstanceState.getInt("player2Points");
        player1Turn = savedInstanceState.getBoolean("player1Turn");
    }





//This is the end of the main acticity
}
