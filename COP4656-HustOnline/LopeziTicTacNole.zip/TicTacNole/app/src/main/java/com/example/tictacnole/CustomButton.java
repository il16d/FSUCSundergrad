package com.example.tictacnole;

import android.content.Context;
import android.util.AttributeSet;

//Custom button with extra fields to keep track of row and column
public class CustomButton extends android.support.v7.widget.AppCompatButton {
    private int row, column;    //i, j
    private String mark;        //X or O


    public CustomButton(Context context) {
        super(context);
    }

    public CustomButton(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CustomButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public String getMark() {
        return mark;
    }

    public void setMark(String mark) {
        this.mark = mark;
    }


    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getColumn() {
        return column;
    }

    public void setColumn(int column) {
        this.column = column;
    }




    //For debugging
    @Override
    public String toString() {
        return "CustomButton{" +
                "row=" + row +
                ", column=" + column +
                '}';
    }
}
