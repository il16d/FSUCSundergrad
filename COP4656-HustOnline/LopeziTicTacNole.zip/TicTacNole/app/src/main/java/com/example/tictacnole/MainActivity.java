package com.example.tictacnole;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


/**
 * Based this project off of a combination of youtube tutorials
 *
 * 1-   https://www.youtube.com/watch?v=MhSBeVsL1bw
 * Used this tutorial to base the player vs player activity manly. This tutorial shows
 * how to create a player vs player and checking to see who wins based on the text that the button is displaying. This tutorial also
 * implements a reset button that would essentially reset the board everytime we want to start a new game.
 *
 * But what this tutorial does not implement is the points for the different players to keep track of who is winning the game
 * also the reset button implemented on that tutorial resets the board after one of the players wins OnClick, instead of auto.
 *
 *
 * I implemented the text views with the names of the player and their score updates as the game progresses based on who wins.
 * I implemented this based on one of the previous projects I did for this class.
 * I changed the reset button to  reset the score of the players and start over a entire new game upon Click.
 * I added a new button that opens a new activity that allows the user to play vs the Computer.
 *
 *
 * 2-   https://www.youtube.com/watch?v=6CM5x4B6BKA
 *
 * Used this tutorial to base my player vs computer AI
 * It showed how to create the Tic tac toe game vs the computer using very basic AI by running through the whole board an detemining where an
 * empty spot might be located to determine the next move and try to block the player it uses the 3 corner strategy by putting
 * the O's on the corners to win the game, or the blocking strategy where the AI blocks the player in a n attempt to prevent it from winning
 *The AI itself is not very smart since it uses the 3 corner strategy and it never gets the chance to start the game,
 * the AI is always at a disadvantage. If the player uses the same strategy over and over they will win the game every single time.
 * Because the Ai is not capable of "remembering" the moves that happened on the previous game.
 *
 *3-   https://www.youtube.com/watch?v=WkIAo2A8o5Q
 * Used this tutorial to learn how to  take care of how to disable landscape mode
 *
 * */












public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button[][] buttons = new Button[3][3];

    private boolean player1Turn = true; //boolean for player turn

    private int roundCount;

    private int player1Points;
    private int player2Points;

    private TextView textViewPlayer1;
    private TextView textViewPlayer2;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewPlayer1 = findViewById(R.id.text_view_p1);
        textViewPlayer2 = findViewById(R.id.text_view_p2);

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                String buttonID = "button_" + i + j;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                buttons[i][j] = findViewById(resID);
                buttons[i][j].setOnClickListener(this);
            }
        }

        Button buttonReset = findViewById(R.id.button_reset);
        buttonReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetGame();
            }
        });

        Button buttonvsComputer= findViewById(R.id.button_computer);
        buttonvsComputer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity2();
            }
        });




    }// end of on create




//Borrowed the code from this source to make the button options work
// https://puruworldofficial.blogspot.com/2018/03/make-your-own-tictactoe-game-in-android.html

    @Override
    public void onClick(View v) {
        if (!((Button) v).getText().toString().equals("")) {
            return;
        }

        if (player1Turn) {
            ((Button) v).setText("X");
        } else {
            ((Button) v).setText("O");
        }

        roundCount++;

        if (checkForWin()) {
            if (player1Turn) {
                player1Wins();
            } else {
                player2Wins();
            }
        } else if (roundCount == 9) {
            draw();
        } else {
            player1Turn = !player1Turn;
        }

    }

    private boolean checkForWin() {
        String[][] field = new String[3][3];

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                field[i][j] = buttons[i][j].getText().toString();
            }
        }

        for (int i = 0; i < 3; i++) {
            if (field[i][0].equals(field[i][1])
                    && field[i][0].equals(field[i][2])
                    && !field[i][0].equals("")) {
                return true;
            }
        }

        for (int i = 0; i < 3; i++) {
            if (field[0][i].equals(field[1][i])
                    && field[0][i].equals(field[2][i])
                    && !field[0][i].equals("")) {
                return true;
            }
        }

        if (field[0][0].equals(field[1][1])
                && field[0][0].equals(field[2][2])
                && !field[0][0].equals("")) {
            return true;
        }

        if (field[0][2].equals(field[1][1])
                && field[0][2].equals(field[2][0])
                && !field[0][2].equals("")) {
            return true;
        }

        return false;
    }


    private void player1Wins() {
        player1Points++;
        Toast.makeText(this, "Player 1 wins!", Toast.LENGTH_SHORT).show();
        updatePointsText();
        resetBoard();
        player1Turn=false;
    }

    private void player2Wins() {
        player2Points++;
        Toast.makeText(this, "Player 2 wins!", Toast.LENGTH_SHORT).show();
        updatePointsText();
            resetBoard();
            player1Turn=true;

    }

    private void draw() {
        Toast.makeText(this, "Draw!", Toast.LENGTH_SHORT).show();

        resetBoard();

        if(player1Turn==true) {
            player1Turn = false;
            player1Turn = false;
        }else{
            player1Turn = true;
            player1Turn = true; // this does not exist

        }

        resetBoard();

    }

    private void updatePointsText() {
        textViewPlayer1.setText("Player 1: " + player1Points);
        textViewPlayer2.setText("Player 2: " + player2Points);
    }

    private void resetBoard() {

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setText("");
            }
        }

        roundCount = 0;

    }//end of reset board


    private void resetGame() {
        player1Points = 0;
        player2Points = 0;
        updatePointsText();
        resetBoard();
    }



    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putInt("roundCount", roundCount);
        outState.putInt("player1Points", player1Points);
        outState.putInt("player2Points", player2Points);
        outState.putBoolean("player1Turn", player1Turn);
    }



    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        roundCount = savedInstanceState.getInt("roundCount");
        player1Points = savedInstanceState.getInt("player1Points");
        player2Points = savedInstanceState.getInt("player2Points");
        player1Turn = savedInstanceState.getBoolean("player1Turn");
    }




//opens computer mode on a new activity
    public void openActivity2() {
        Intent intent = new Intent(this, MainActivity2.class);
        startActivity(intent);
    }
}