package com.example.assignment2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {



    private int currentImage = R.drawable.nole;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //register the button
        final Button clickButton = findViewById(R.id.Button1);

        OnClickListener changeButtonListener = new OnClickListener() {
            @Override
            public void onClick(View v) {

                ImageView imageView = findViewById(R.id.imageView1);

                int nole = R.drawable.nole;
                int gator = R.drawable.koolgator;

                //"show me a gator"
                if (currentImage == nole)
                {
                    imageView.setImageResource(R.drawable.koolgator);
                    clickButton.setText(R.string.nole);
                    currentImage = gator;
                }
                else
                {
                    imageView.setImageResource(R.drawable.nole);
                    clickButton.setText(R.string.gator);
                    currentImage = nole;
                }

            }
        };

        clickButton.setOnClickListener(changeButtonListener);
    }

}

