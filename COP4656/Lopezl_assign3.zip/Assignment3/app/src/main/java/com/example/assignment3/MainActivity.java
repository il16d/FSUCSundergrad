package com.example.assignment3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    Button button1, button2, button3;
    //B1=Rock B2= paper B3= scissors
    TextView textView3;
    //Score board
    ImageView imageView1, imageView2;
    //IG1= human IG2= comp

    int player, computers =0;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        button1= (Button) findViewById(R.id.button1);
        button2= (Button) findViewById(R.id.button2);
        button3= (Button) findViewById(R.id.button3);

        imageView1=(ImageView) findViewById(R.id.imageView1);
        imageView2=(ImageView) findViewById(R.id.imageView2);

        textView3 = (TextView) findViewById(R.id.textView3);


//Rock
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                imageView1.setImageResource(R.drawable.rock);
                String message=play_turn("Rock");
                Toast.makeText(MainActivity.this,message,Toast.LENGTH_SHORT).show();
                textView3.setText("Player Score: "+Integer.toString(player)+" Computer Score: "+Integer.toString(computers) );

            }
        });
//Paper
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageView1.setImageResource(R.drawable.paper);
                String message= play_turn("Paper");
                Toast.makeText(MainActivity.this,message,Toast.LENGTH_SHORT).show();
                textView3.setText("Player Score: "+Integer.toString(player)+" Computer Score: "+Integer.toString(computers) );
            }
        });

//Scissors
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageView1.setImageResource(R.drawable.scissors);
                String message=play_turn("Scissors");
                Toast.makeText(MainActivity.this,message,Toast.LENGTH_SHORT).show();
                textView3.setText("Player Score: "+Integer.toString(player)+" Computer Score: "+Integer.toString(computers) );

            }
        });





    }

     public String play_turn(String Choice) //Choice is the players choice
     {
        String computer=""; //computer choice
         Random number = new Random(); //random number for the computer

         int Computernum=number.nextInt(3)+1; //from 1 to 3
         if(Computernum==1) {
             computer="Rock";

         } else
             if(Computernum==2) {
             computer="Paper";

         }   else{
             if(Computernum==3) {
                 computer="Scissors";
             }

     }
//image based on comp choice
         if(computer=="Rock"){

             imageView2.setImageResource(R.drawable.rock);
         }else{
             if(computer=="Paper"){

                 imageView2.setImageResource(R.drawable.paper);
             }else{
                 if(computer=="Scissors"){

                     imageView2.setImageResource(R.drawable.scissors);
                 }
             }
         }


//Determine the winner

            if(computer==Choice){
                return"Draw";
            }
            else if(Choice=="Rock" && computer=="Scissors"){
                player++;
                return "Rock wins";

            } else if(Choice=="Rock"&&computer=="Paper"){
                computers++;
                return "Paper wins";
            }
            else if(Choice=="Scissors"&&computer=="Rock"){
                computers++;
                return "Rock wins";
            } else if(Choice=="Scissors"&&computer=="Paper"){
                player++;
                return "Scissors win";
            } else if(Choice=="Paper"&&computer=="Scissors"){
                computers++;
                return "Scissors win";
            } else if(Choice=="Paper"&&computer=="Rock"){
                player++;
                return "Paper wins";
            }
            else return "nothing";





     }


}
