package edu.fsu.cs.cen4020.hw2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.Arrays;

public class RegisterUserActivity extends AppCompatActivity {





    @Override
    protected void onCreate(Bundle savedInstanceState) {




        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);

        Button resetButton = (Button) findViewById(R.id.button_reset);
        Button registerButton = (Button) findViewById(R.id.button_register);



        final EditText emailText = findViewById(R.id.emailText);
        final EditText passwordText = findViewById(R.id.passwordText);
        final EditText confirmText = findViewById(R.id.confirmText);

        final EditText empidText = findViewById(R.id.empidText);



        final EditText nameText = findViewById(R.id.nameText);
        final Spinner classSpinner = findViewById(R.id.spinner);
        final RadioGroup roleGroup = findViewById(R.id.roleGroup);
        final CheckBox termsCheckbox = findViewById(R.id.checkBox);



        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                empidText.setText("");
                emailText.setText("");
                passwordText.setText("");
                confirmText.setText("");
                nameText.setText("");
                classSpinner.setSelection(0);
                roleGroup.clearCheck();
                termsCheckbox.setChecked(false);


            }
        });


        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boolean passableInfo = true;
                String errors = "";


                if (empidText.getText().toString().isEmpty() ) {

                    errors += "\nInvalid Employee ID";
                    passableInfo = false;


                }

                if (emailText.getText().toString().isEmpty() || !emailText.getText().toString().contains("@") || !emailText.getText().toString().contains(".com")) {

                    errors += "\nInvalid email address";
                    passableInfo = false;
                }
                if (passwordText.getText().toString().isEmpty()) {

                    passableInfo = false;
                }
                if (confirmText.getText().toString().isEmpty()) {

                    errors += "\n'Confirm Password' field cannot be left empty";
                    passableInfo = false;
                }
                if (nameText.getText().toString().isEmpty()) {

                    errors += "\nName cannot be left empty";
                    passableInfo = false;
                }
                if (classSpinner.getSelectedItem().toString().equals("Select a class...")) {

                    errors += "\nMust choose a class";
                    passableInfo = false;
                }
                if (roleGroup.getCheckedRadioButtonId() == -1) {

                    errors += "\nMust choose a gender (Male or Female)";
                    passableInfo = false;
                }
                if (!termsCheckbox.isChecked()) {
                    errors += "\nMust agree to terms to proceed)";
                    passableInfo = false;
                } else {
                    int selectedRadioID = roleGroup.getCheckedRadioButtonId();
                    RadioButton rb = (RadioButton) findViewById(selectedRadioID);

                }
                if (passableInfo) {
                    String[] emplid = getResources().getStringArray(R.array.empids);
                     if (!Arrays.asList(emplid).contains(empidText.getText().toString())) {

                        Toast.makeText(getApplicationContext(), "Incorrect Employee ID", Toast.LENGTH_LONG).show();
                    } else if(!passwordText.getText().toString().equals(confirmText.getText().toString())){
                        Toast.makeText(getApplicationContext(), "Password  and Confirm Password must match", Toast.LENGTH_LONG).show();
                        passableInfo = false;
                    }
                    else {

                        Toast.makeText(getApplicationContext(), "Thank you for your acceptable information", Toast.LENGTH_LONG).show();

                        loadNewActivity(empidText,emailText, passwordText, nameText, classSpinner, roleGroup);
                    }
                } else {

                    Toast.makeText(getApplicationContext(), "Encountered the following errors: " + errors, Toast.LENGTH_LONG).show();
                }


            }
        });


    }

    public void loadNewActivity(EditText empidText, EditText emailText, EditText passwordText, EditText nameText, Spinner classSpinner, RadioGroup roleGroup){
        Intent myIntent = new Intent(RegisterUserActivity.this, DisplayUserActivity.class);
        myIntent.putExtra("empid", empidText.getText().toString());
        myIntent.putExtra("email", emailText.getText().toString());
        myIntent.putExtra("password", passwordText.getText().toString());
        myIntent.putExtra("name", nameText.getText().toString());
        myIntent.putExtra("class", classSpinner.getSelectedItem().toString());
        int selectedRadioID = roleGroup.getCheckedRadioButtonId();
        RadioButton rb = findViewById(selectedRadioID);
        myIntent.putExtra("role", rb.getText().toString());

        RegisterUserActivity.this.startActivity(myIntent);
    }






}
